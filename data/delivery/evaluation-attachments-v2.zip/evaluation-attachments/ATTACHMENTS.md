# Evaluation attachments

This archive contains the evaluation and online-check artifacts that are excluded from the Git repository by
`data/`. Paths below match the project paths so references in `README.md` and `PLANS/plan_1003.md` can be followed
directly. The archive contains 218 files under `data/`, copied byte-for-byte from the local results. `SHA256SUMS`
lists every file in this folder except itself, including this document.

To verify the extracted archive from the folder containing `ATTACHMENTS.md` and `SHA256SUMS`:

- Windows with Git Bash: `sha256sum -c SHA256SUMS`
- macOS/Linux: `tr -d '\r' < SHA256SUMS | shasum -a 256 -c -`

The copies and their source files were compared by SHA-256 on 2026-10-25. A credential-pattern scan found no API
key or request authorization header. Saved Gemini thought signatures are encrypted API state used to continue
model reasoning, not credentials. Local Windows account names in four historical artifacts were replaced with `USER` for this v2 archive. Answers and
retrieved contexts quote the rulebook text already represented by `data/processed/` in the repository.

These files support review of both historical results and the final current-system evaluation. Running any command
again with another key creates a new run; it does not reproduce the exact saved model output.

## 1. Evaluation artifacts (`data/eval/`)

### Trial: 3 questions on the five attack steps (R52, R57–R60)

| Path | Contents |
|---|---|
| `data/eval/round1/` | Generated and retained test sets, knowledge graph, manifest and generation/scoring logs |
| `data/eval/runs/trial/answers/` | Three saved answers with contexts, traces and request counts |
| `data/eval/runs/trial/scores.jsonl` | Fifteen metric records |

The trial predates the freeze record, and its exact code revision was not confirmed.

### Round 2: 10 questions on 13 documents (R64–R67)

| Path | Contents |
|---|---|
| `data/eval/freeze-round2.json` | Frozen commit, code, prompt, index, lock, model and setting hashes |
| `data/eval/knowledge_graph*.json` | RAGAS graph and progress state |
| `data/eval/testset.generated.jsonl` | Twelve generated questions |
| `data/eval/testset.jsonl` | Ten retained questions, also used by Round 3 |
| `data/eval/*round2*.log` | Generation, answering and scoring logs |
| `data/eval/runs/round2/answers/` | Ten saved answers with contexts, traces and request counts |
| `data/eval/runs/round2/scores.jsonl` | Fifty metric records |

### Round 3: locked R94-system evaluation (R94–R95)

Round 3 is a historical result of the locked R94 implementation. Later R95–R102 changes do not inherit these
scores.

| Path | Contents |
|---|---|
| `data/eval/answer-round3.log`, `score-round3.log` | Answering and scoring command logs |
| `data/eval/runs/round3/inputs.json` | Input, code, lock, index and database fingerprints |
| `data/eval/runs/round3/answers/` | Ten saved answers with agent/retriever contexts, traces and request counts |
| `data/eval/runs/round3/scores.jsonl` | Fifty valid metric records: 10 questions × 5 metrics |

The README and plan R95 document the human limitations for q002, q007 and q009.

### Round 4: final current-system evaluation (R103)

Round 4 belongs to frozen commit `2f3d3529533528501a35a3950128bf38d4a27f40` and the input fingerprints in its
manifest. Its 10 saved answers and 50 scores are separate from the historical Round 3 result.

| Path | Contents |
|---|---|
| `data/eval/answer-round4-final.log`, `score-round4-final.log` | Answering and scoring command logs, including resumptions |
| `data/eval/runs/round4-final/inputs.json` | Input, code, lock, index, database and evaluation fingerprints |
| `data/eval/runs/round4-final/answers/` | Ten saved answers with contexts, traces and request counts |
| `data/eval/runs/round4-final/scores.jsonl` | Fifty valid metric records: 10 questions × 5 metrics |
| `data/checks/final-20261024/online/checkpoint-before-new-key-20261025/` | Non-destructive backup of the 47-score checkpoint and all 10 answers before the final resume |

## 2. Acceptance and diagnosis (`data/checks/`)

| Path | Contents | Plan entry |
|---|---|---|
| `data/checks/2026101*_test_*.json`, `20261014-152202_final_variants.json` | Gemini compatibility and signature reports | R38, R40, R41 |
| `data/checks/acceptance/20261015_scratch-driver/` | Initial CLI acceptance and R45 retests | R45, R46 |
| `data/checks/acceptance/20261018-121418_scoring_interactive/` | Scoring acceptance: CLI pass, answer fail | R61 |
| `data/checks/acceptance/20261018-122354_stratagem_question/` | Stratagem question-mode output | R62 |
| `data/checks/diagnosis/20261018-retrieval-misses/` | Retrieval-miss snapshots and q004 query-vector reproduction | R63 |
| `data/checks/diagnosis/20261020-mission-context/` | Page-footer and heading-path diagnosis | R71 |
| `data/checks/r94-20261023/online/` | Locked six-scenario Stage C reports, traces, consoles, review and request ledger | R94 |
| `data/checks/r102-20261024/online/` | Final bounded Toughness → Wardens report, trace, consoles, ledger and hashes | R102 |
| `data/checks/final-20261024/online/stage-c/` | Final current-system six-scenario Stage C traces, consoles and reports: 6/6 pass | R103 |
| `data/checks/final-20261024/online/` | Freeze, request ledger, checkpoint backup, completion report and hashes for the final campaign | R103 |

## 3. Retrieval and prompt experiments (`data/checks/experiments/`)

| Path | Contents | Adopted |
|---|---|---|
| `20261018-rrf-weights/` | Offline 2:1 fusion comparison | No; 1:1 retained |
| `20261019-rrf-retest/` | Three online 2:1 fusion cases and two new-query rankings | No; 1:1 retained |
| `20261020-prompt-revision/` | Candidate prompt replay on six fixed contexts | No |
| `20261020-footer-replay/` | Page-footer replay on four fixed contexts | Footers retained; replay is supporting evidence |

## Limits of the archive

- `__pycache__/` directories are omitted.
- Exact reruns of old ranking experiments also need the original index, chunk file and code revision named by each
  manifest. Rebuilding an index is a new reproduction run.
- RAGAS judge explanations were not saved, so score disagreements require reading the answer, reference and
  contexts rather than an intermediate judge rationale.
- The first two rounds predate the page-footer change. Round 3 belongs only to R94. R95–R102 do not inherit its
  scores. Round 4 is the separate final evaluation of the frozen current system; comparisons between the rounds are
  observational because several implementation and evaluation inputs changed.
