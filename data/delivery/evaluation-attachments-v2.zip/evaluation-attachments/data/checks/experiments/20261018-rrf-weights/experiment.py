"""Offline experiment: the weight of BM25 in Reciprocal Rank Fusion (plan R63), everything else unchanged.

Run from the repository root:

    uv run python data/checks/experiments/20261018-rrf-weights/experiment.py --list
    uv run python data/checks/experiments/20261018-rrf-weights/experiment.py --embed --budget 3 --send
    uv run python data/checks/experiments/20261018-rrf-weights/experiment.py --compare vectors-<time>.json

Two fusions only: the present one, vector 1 and BM25 1, and the candidate, vector 2 and BM25 1; written as
`1 / (RRF_K + vector rank) + w / (RRF_K + BM25 rank)`, they are w = 1.0 and w = 0.5 (scaling both weights by the same
number does not change a ranking). `TOP_K`, the tokenisation and the queries are unchanged; nothing of the system is.

`--list` writes `labels.json` once, for review: every saved search of the two evaluation rounds (each question as
asked, and the chat's own queries) and of the online acceptance runs, with the answer it belongs to (its file), its
kind, its query, the sections its question's reference contexts come from (for the acceptance runs, labelled by hand
in `HAND_LABELS`), the chunks it returned then (for the chat's searches), and, for the three misses diagnosed in R63,
the chunk it should have kept. The sections are a proxy: other sections may answer as well, and a section has several
chunks; the share of them found is reported only beside the chunks each fusion adds or drops, saved whole, which are
read. The searches of one answer are taken together with the union of their labels.

`--embed --send` embeds every query once, in one batch (its texts count in the usage), started once, the SDK's
retries allowed within its own cap of HTTP attempts, no more budget and no new start, and saves the vectors with what they were made from, whether the request succeeds or not. They
reproduce the searches under the current settings; the original query vectors were not saved (one of `q004`'s, from
R63's diagnosis, is compared with its new one).

`--compare FILE` checks that the vectors match the current index, model, dimension, task type and the reviewed
labels' queries, then ranks every chunk as `RulesRetriever.search` does under each fusion and writes, for every
search and for every answer (the chat's searches of one answer together), the top `TOP_K`, the chunks added and
dropped by the candidate with their text, the sections found, and the targets' ranks.
"""

import argparse
import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
from rank_bm25 import BM25Okapi

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT))

from src.rag.chatbot.agent import RunTrace, answer_from_trace  # noqa: E402
from src.rag.chunker.markdown_chunker import jsonl_to_chunks  # noqa: E402
from src.rag.config import EMBEDDING_DIM, RULES_CHUNKS, RULES_EMBEDDINGS, TOP_K, Settings  # noqa: E402
from src.rag.llm.budget import AttemptCounter, RequestBudget  # noqa: E402
from src.rag.llm.gemini import GeminiEmbedder  # noqa: E402
from src.rag.retriever.rules_retriever import RRF_K, tokens  # noqa: E402
from src.rag.storage.evaluation_runs import load_answers, load_testset  # noqa: E402
from src.rag.storage.rules_index import load_embeddings  # noqa: E402

HERE = Path(__file__).resolve().parent
LABELS = HERE / "labels.json"
EMBEDDING_MODEL = "gemini-embedding-001"
TASK_TYPE = "RETRIEVAL_QUERY"
FUSIONS = {"present (vector 1, BM25 1)": 1.0, "candidate (vector 2, BM25 1)": 0.5}
RUNS = {"trial": ROOT / "data/eval/round1/testset.jsonl", "round2": ROOT / "data/eval/testset.jsonl"}
ACCEPTANCE = ROOT / "data/checks/acceptance"
HAND_LABELS = {
    "scoring points victory points": ["CAPTURE AND CONTROL"],
    "scoring points": ["CAPTURE AND CONTROL"],
    "objectives victory conditions": ["CAPTURE AND CONTROL", "11 DETERMINE VICTOR"],
    "using stratagems": ["STRATAGEMS"],
    "Grenades": ["GRENADE"],
    "grenades": ["GRENADE"],
}
# The misses of R63, by (answer, kind, query): the chunk each search should have kept.
TARGETS = {
    ("data/checks/acceptance/20261018-121418_scoring_interactive/trace.json", "agent",
     "scoring points victory points"): "core_rules-0243",
    ("data/eval/runs/trial/answers/q004.json", "agent", "Allocate Attack and Saving Throw"): "core_rules-0081",
    ("data/eval/runs/trial/answers/q004.json", "direct", None): "core_rules-0081",
}
R63_Q004_VECTOR = ROOT / "data/checks/diagnosis/20261018-retrieval-misses/q004_direct_embedding-20261018-200307.json"

chunks = jsonl_to_chunks(RULES_CHUNKS.read_text(encoding="utf-8"))
ids = [chunk.chunk_id for chunk in chunks]
vectors = load_embeddings(RULES_EMBEDDINGS, chunks, EMBEDDING_MODEL)
bm25 = BM25Okapi([tokens(chunk.text) for chunk in chunks])


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT)).replace("\\", "/")


def index_inputs() -> dict:
    return {rel(RULES_CHUNKS): sha256(RULES_CHUNKS), rel(RULES_EMBEDDINGS): sha256(RULES_EMBEDDINGS)}


def searches() -> list[dict]:
    """Every saved search, with the answer it belongs to: an answer file, or a trace file."""
    found = []
    for run, testset in RUNS.items():
        sections = {
            q.question_id: sorted({s for c in q.reference_contexts for s in re.findall(r"Section: ([^\n]+)", c)})
            for q in load_testset(testset)
        }
        answers_dir = ROOT / f"data/eval/runs/{run}/answers"
        for answer in load_answers(answers_dir):
            path = answers_dir / f"{answer.question.question_id}.json"
            relevant = sections[answer.question.question_id]
            found.append({"answer": rel(path), "kind": "direct", "query": answer.question.question,
                          "relevant": relevant})
            for call in answer_from_trace(answer.trace).tool_calls:
                if call.name == "search_rules":
                    found.append({"answer": rel(path), "kind": "agent", "query": call.arguments["query"],
                                  "relevant": relevant, "then": [r.chunk.chunk_id for r in call.result]})
    for trace in sorted(ACCEPTANCE.glob("*/trace.json")) + sorted(ACCEPTANCE.glob("*/q*_trace.json")):
        for call in answer_from_trace(RunTrace.from_dict(json.loads(trace.read_text(encoding="utf-8")))).tool_calls:
            if call.name == "search_rules":
                query = call.arguments["query"]
                found.append({"answer": rel(trace), "kind": "agent", "query": query, "relevant": HAND_LABELS[query],
                              "then": [r.chunk.chunk_id for r in call.result]})
    for search in found:
        key = (search["answer"], search["kind"], None if search["kind"] == "direct" else search["query"])
        if key in TARGETS:
            search["target"] = TARGETS[key]
    return found


def ranking(query_vector: np.ndarray, query: str, w: float) -> list[int]:
    """`RulesRetriever.search`'s order, BM25's contribution weighted by `w`."""
    by_vector = np.argsort(-(vectors @ query_vector), kind="stable")
    scores = bm25.get_scores(tokens(query))
    by_keyword = [int(i) for i in np.argsort(-scores, kind="stable") if scores[i] > 0]
    fused = np.zeros(len(chunks))
    for weight, order in ((1.0, by_vector), (w, by_keyword)):
        for position, index in enumerate(order, start=1):
            fused[index] += weight / (RRF_K + position)
    return [int(i) for i in np.argsort(-fused, kind="stable")]


def described(chunk_id: str) -> dict:
    chunk = chunks[ids.index(chunk_id)]
    return {"chunk": chunk_id, "section": chunk.section, "pages": chunk.pages, "text": chunk.text}


def found_sections(top: list[str], relevant: list[str]) -> list[str]:
    return sorted({chunks[ids.index(c)].section for c in top} & set(relevant))


def compare(labels: list[dict], embedded: dict) -> dict:
    vector_of = dict(zip(embedded["queries"], np.array(embedded["vectors"]), strict=True))
    (present, candidate) = FUSIONS.values()
    rows = []
    for search in labels:
        orders = {w: ranking(vector_of[search["query"]], search["query"], w) for w in FUSIONS.values()}
        tops = {w: [ids[i] for i in order[:TOP_K]] for w, order in orders.items()}
        row = {k: search[k] for k in ("answer", "kind", "query", "relevant")}
        row["top"] = {name: tops[w] for name, w in FUSIONS.items()}
        row["sections_found"] = {name: found_sections(tops[w], search["relevant"]) for name, w in FUSIONS.items()}
        row["added_by_candidate"] = [described(c) for c in tops[candidate] if c not in tops[present]]
        row["dropped_by_candidate"] = [described(c) for c in tops[present] if c not in tops[candidate]]
        if "target" in search:
            target = ids.index(search["target"])
            row["target"] = search["target"]
            row["target_rank"] = {name: orders[w].index(target) + 1 for name, w in FUSIONS.items()}
        if "then" in search:
            row["present_matches_then"] = tops[present] == search["then"]
        rows.append(row)
    answers = {}
    for row in rows:
        if row["kind"] == "agent":
            group = answers.setdefault(row["answer"], {"answer": row["answer"], "relevant": row["relevant"],
                                                       "queries": [], "union": {name: [] for name in FUSIONS}})
            group["queries"].append(row["query"])
            group["relevant"] = sorted(set(group["relevant"]) | set(row["relevant"]))
            for name in FUSIONS:
                group["union"][name] += [c for c in row["top"][name] if c not in group["union"][name]]
    for group in answers.values():
        group["sections_found"] = {name: found_sections(group["union"][name], group["relevant"]) for name in FUSIONS}
        present_union, candidate_union = (group["union"][name] for name in FUSIONS)
        group["added_by_candidate"] = [described(c) for c in candidate_union if c not in present_union]
        group["dropped_by_candidate"] = [described(c) for c in present_union if c not in candidate_union]
    return {"searches": rows, "agent_answers": list(answers.values())}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--list", action="store_true", help="write labels.json for review, if not there yet")
    parser.add_argument("--embed", action="store_true", help="embed every labelled query once, in one batch")
    parser.add_argument("--budget", type=int, default=3, help="the most embedding attempts, retries included")
    parser.add_argument("--send", action="store_true", help="send; without it, only say what would be sent")
    parser.add_argument("--compare", metavar="VECTORS", help="compare the two fusions on these saved vectors")
    args = parser.parse_args()
    stamp = time.strftime("%Y%m%d-%H%M%S")
    git = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True)
    code = git.stdout.strip()
    if git.returncode != 0 or not code:
        sys.exit(f"the commit cannot be read (git rev-parse: {git.stderr.strip()}); nothing is sent")
    if args.list:
        if LABELS.exists():
            print(f"{LABELS} exists: it is the reviewed file, not written again.")
        else:
            LABELS.write_text(json.dumps(searches(), ensure_ascii=False, indent=1) + "\n", encoding="utf-8",
                              newline="\n")
            print(f"{LABELS} written, for review.")
    labels = json.loads(LABELS.read_text(encoding="utf-8"))
    current = [(s["answer"], s["kind"], s["query"]) for s in searches()]
    if [(s["answer"], s["kind"], s["query"]) for s in labels] != current:
        sys.exit("labels.json does not list the saved searches of the current files.")
    queries = list(dict.fromkeys(s["query"] for s in labels))
    print(f"{len(labels)} searches, {len(queries)} distinct queries, labels {sha256(LABELS)[:12]}")
    if args.embed and not args.send:
        print(f"Would embed {len(queries)} queries in one batch, at most {args.budget} attempts. Nothing sent.")
    elif args.embed:
        counter = AttemptCounter(RequestBudget(args.budget, 0))
        record = {"index": index_inputs(), "model": EMBEDDING_MODEL, "dimension": EMBEDDING_DIM,
                  "task_type": TASK_TYPE, "labels": sha256(LABELS), "code": code, "queries": queries,
                  "budget": args.budget, "complete": False,
                  "note": "a reproduction under the current settings; the original query vectors were not saved"}
        try:
            embedder = GeminiEmbedder(Settings(), {"transport": counter})
            assert embedder.model == EMBEDDING_MODEL
            matrix = embedder.embed(queries, TASK_TYPE)
            record |= {"complete": True, "vectors": [[float(x) for x in row] for row in matrix]}
        except BaseException as error:
            record["error"] = f"{type(error).__name__}: {error}"
        record["attempts"] = counter.attempts
        path = HERE / f"vectors-{stamp}.json"
        path.write_text(json.dumps(record, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
        print(f"complete {record['complete']}, attempts {record['attempts']}, error {record.get('error')} -> {path}")
    if args.compare:
        path = HERE / args.compare
        embedded = json.loads(path.read_text(encoding="utf-8"))
        expected = {"index": index_inputs(), "model": EMBEDDING_MODEL, "dimension": EMBEDDING_DIM,
                    "task_type": TASK_TYPE, "queries": queries, "complete": True}
        mismatched = [k for k, v in expected.items() if embedded.get(k) != v]
        if mismatched:
            sys.exit(f"{path.name} does not match the current inputs: {mismatched}")
        old = np.array(json.loads(R63_Q004_VECTOR.read_text(encoding="utf-8"))["query_vector"])
        (q4,) = [s["query"] for s in labels if s["answer"].endswith("trial/answers/q004.json") and s["kind"] == "direct"]
        new = np.array(embedded["vectors"][queries.index(q4)])
        result = {"code": code, "script": sha256(Path(__file__)), "labels": sha256(LABELS), "vectors": path.name,
                  "vectors_sha256": sha256(path), "fusions": FUSIONS, "top_k": TOP_K, "rrf_k": RRF_K,
                  "q004_vector_cosine_with_r63": float(old @ new / np.linalg.norm(old) / np.linalg.norm(new))}
        result |= compare(labels, embedded)
        out = HERE / f"compare-{stamp}.json"
        out.write_text(json.dumps(result, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
        print(f"comparison -> {out}")


if __name__ == "__main__":
    main()
