"""The two queries the chat wrote anew in the retest, ranked under both fusions on one vector each (plan R69).

Run from the repository root:

    uv run python data/checks/experiments/20261019-rrf-retest/new_queries.py
    uv run python data/checks/experiments/20261019-rrf-retest/new_queries.py --budget 3 --send

Without `--send` nothing is sent. With it, the two queries are embedded in one batch, started once, the SDK's
retries allowed within the cap of HTTP attempts; the vectors are saved with what they were made from, whether the
request succeeds or not. Then, offline, each query's one vector is ranked as `RulesRetriever.search` does under the
present fusion (vector 1, BM25 1) and the candidate (vector 2, BM25 1): the target's rank and the top `TOP_K` under
each, and a check that the candidate's top `TOP_K` is what the chat received in the retest. This tells whether the
query finds its target under both fusions or under the candidate only; it does not tell where an answer's gain came
from. Nothing is asked of the chat.
"""

import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT))

from src.rag.config import EMBEDDING_DIM, TOP_K, Settings  # noqa: E402
from src.rag.llm.budget import AttemptCounter, RequestBudget  # noqa: E402
from src.rag.llm.gemini import GeminiEmbedder  # noqa: E402

spec = importlib.util.spec_from_file_location("experiment", HERE.parent / "20261018-rrf-weights/experiment.py")
experiment = importlib.util.module_from_spec(spec)
spec.loader.exec_module(experiment)

# Each new query, its target, and the top 5 the chat received in the retest (under the candidate).
QUERIES = {
    "Victory points scoring": ("core_rules-0243", "case-scoring-20261019-180720.json", 2),
    "ALLOCATE ATTACK and Saving Throw after Successful Wound": ("core_rules-0081", "case-trial-q004-20261019-180720.json", 1),
}


def received(case_file: str, nth: int) -> list[str]:
    """The chunk ids of the `nth` rules search the chat ran in a retest case."""
    record = json.loads((HERE / case_file).read_text(encoding="utf-8"))
    results = [m["data"]["content"] for m in record["trace"]["messages"] if m["type"] == "tool"]
    return [line[1:].split("]")[0] for line in results[nth - 1].split("\n") if line.startswith("[core_rules")]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--budget", type=int, default=3, help="the most embedding attempts, retries included")
    parser.add_argument("--send", action="store_true", help="send; without it, only say what would be sent")
    args = parser.parse_args()
    queries = list(QUERIES)
    expected = {q: received(case, nth) for q, (_, case, nth) in QUERIES.items()}
    if not args.send:
        print(f"Would embed {len(queries)} queries in one batch, at most {args.budget} attempts. Nothing sent.")
        print(f"The candidate's top {TOP_K} the chat received: {expected}")
        return
    git = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True)
    if git.returncode != 0 or not git.stdout.strip():
        sys.exit(f"the commit cannot be read: {git.stderr.strip()}; nothing is sent")
    stamp = time.strftime("%Y%m%d-%H%M%S")
    counter = AttemptCounter(RequestBudget(args.budget, 0))
    record = {"code": git.stdout.strip(), "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "index": experiment.index_inputs(), "model": experiment.EMBEDDING_MODEL, "dimension": EMBEDDING_DIM,
              "task_type": experiment.TASK_TYPE, "queries": queries, "budget": args.budget, "complete": False}
    try:
        embedder = GeminiEmbedder(Settings(), {"transport": counter})
        assert embedder.model == experiment.EMBEDDING_MODEL
        matrix = embedder.embed(queries, experiment.TASK_TYPE)
        record |= {"complete": True, "vectors": [[float(x) for x in row] for row in matrix]}
    except BaseException as error:
        record["error"] = f"{type(error).__name__}: {error}"
    record["attempts"] = counter.attempts
    vectors_path = HERE / f"new-query-vectors-{stamp}.json"
    vectors_path.write_text(json.dumps(record, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print(f"complete {record['complete']}, attempts {record['attempts']}, error {record.get('error')}")
    if not record["complete"]:
        return
    rows = []
    for query, vector in zip(queries, np.array(record["vectors"]), strict=True):
        target = QUERIES[query][0]
        row = {"query": query, "target": target, "received_in_retest": expected[query]}
        for name, w in experiment.FUSIONS.items():
            order = experiment.ranking(vector, query, w)
            row[name] = {"target_rank": order.index(experiment.ids.index(target)) + 1,
                         "top": [experiment.ids[i] for i in order[:TOP_K]]}
        row["candidate_matches_retest"] = row["candidate (vector 2, BM25 1)"]["top"] == expected[query]
        rows.append(row)
    out = HERE / f"new-queries-compare-{stamp}.json"
    result = {"vectors": vectors_path.name, "vectors_sha256": hashlib.sha256(vectors_path.read_bytes()).hexdigest(),
              "top_k": TOP_K, "rrf_k": experiment.RRF_K, "fusions": experiment.FUSIONS, "rows": rows}
    out.write_text(json.dumps(result, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    for row in rows:
        ranks = {name: row[name]["target_rank"] for name in experiment.FUSIONS}
        print(f"{row['query']}: {row['target']} ranks {ranks}; candidate matches retest {row['candidate_matches_retest']}")
    print(f"-> {out.name}")


if __name__ == "__main__":
    main()
