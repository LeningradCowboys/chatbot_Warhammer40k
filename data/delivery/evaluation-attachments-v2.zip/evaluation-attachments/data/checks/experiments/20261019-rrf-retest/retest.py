"""Online retest of the fusion 2:1 (vector 2, BM25 1) on three cases (plan R68), the chat otherwise unchanged.

Run from the repository root:

    uv run python data/checks/experiments/20261019-rrf-retest/retest.py --check
    uv run python data/checks/experiments/20261019-rrf-retest/retest.py --chat-budget 25 --embedding-budget 20 --send

`--check` sends nothing: on the query vectors of R68's experiment, `WeightedRulesRetriever` with weight 1 must give
`RulesRetriever.search`'s results, and with weight 0.5 the top 5 of R68's candidate. With `--send`, the chat is built
as `src/scripts/chat.py` builds it, the rules retriever swapped for `WeightedRulesRetriever(bm25_weight=0.5)`, and
each case is asked once on a new thread; the answer, the chunks it received, the candidate's own top 5 for the
question as asked, the trace and the requests are saved in `case-<id>-<time>.json`, with the script's SHA-256;
every case is saved as soon as it ends, failed or not (with the thread's trace so far), a case whose tools failed
stops the next ones, and a run that raises stops at once. Nothing of the system is changed.
"""

import argparse
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT))

from src.rag.chatbot.agent import ChatAgent, chunk_block  # noqa: E402
from src.rag.chatbot.prompts import build_system_prompt  # noqa: E402
from src.rag.chunker.markdown_chunker import jsonl_to_chunks  # noqa: E402
from src.rag.config import (  # noqa: E402
    CLEAN_DB,
    RULES_CHUNKS,
    RULES_EMBEDDINGS,
    SQL_MAX_ROWS,
    SQL_SCHEMA,
    TOP_K,
    Settings,
)
from src.rag.evaluation.scoring import agent_contexts  # noqa: E402
from src.rag.llm.budget import AttemptCounter, RequestBudget  # noqa: E402
from src.rag.llm.gemini import MIN_SECONDS_BETWEEN_CHAT_REQUESTS, GeminiEmbedder, create_chat_model  # noqa: E402
from src.rag.retriever.rules_retriever import RRF_K, RetrievedChunk, RulesRetriever, tokens  # noqa: E402
from src.rag.retriever.sql_retriever import SqlRetriever  # noqa: E402
from src.rag.storage.evaluation_runs import load_testset  # noqa: E402
from src.rag.storage.rules_index import load_embeddings  # noqa: E402

HERE = Path(__file__).resolve().parent
BM25_WEIGHT = 0.5  # vector 2, BM25 1
EXPERIMENT = ROOT / "data/checks/experiments/20261018-rrf-weights"
CASES = {
    "scoring": ("What are the different ways to score points?", "the ways to score (R61): the scoring rule, "
                "with the mission's scope, its timing and the rule of victory"),
    "trial-q004": (None, "the trial's q004 (R60): does the better search of the question make a better answer"),
    "round2-q009": (None, "the round's q009 (R67): a case where relevant evidence decreased"),
}


class WeightedRulesRetriever(RulesRetriever):
    """`RulesRetriever`, BM25's ranks weighted by `bm25_weight` in the fusion (the vector's weight is 1)."""

    def __init__(self, chunks, vectors, embedder, bm25_weight: float):
        super().__init__(chunks, vectors, embedder)
        self.bm25_weight = bm25_weight

    def search(self, query: str, top_k: int) -> list[RetrievedChunk]:
        query_vector = self._embedder.embed([query], "RETRIEVAL_QUERY")[0]
        by_vector = np.argsort(-(self._vectors @ query_vector), kind="stable")
        bm25 = self._bm25.get_scores(tokens(query))
        by_keyword = [int(i) for i in np.argsort(-bm25, kind="stable") if bm25[i] > 0]
        fused = np.zeros(len(self._chunks))
        for weight, ranking in ((1.0, by_vector), (self.bm25_weight, by_keyword)):
            for rank, index in enumerate(ranking, start=1):
                fused[index] += weight / (RRF_K + rank)
        best = np.argsort(-fused, kind="stable")[:top_k]
        return [RetrievedChunk(self._chunks[i], float(fused[i])) for i in best]


class SavedVectors:
    """An `Embedder` that returns R68's saved query vectors, and sends nothing."""

    model = "gemini-embedding-001"

    def __init__(self, record: dict):
        self._of = dict(zip(record["queries"], np.array(record["vectors"]), strict=True))

    def embed(self, texts: list[str], task_type: str) -> np.ndarray:
        return np.array([self._of[text] for text in texts])


def questions() -> dict[str, str]:
    asked = {"scoring": CASES["scoring"][0]}
    (trial,) = [q for q in load_testset(ROOT / "data/eval/round1/testset.jsonl") if q.question_id == "q004"]
    (round2,) = [q for q in load_testset(ROOT / "data/eval/testset.jsonl") if q.question_id == "q009"]
    return asked | {"trial-q004": trial.question, "round2-q009": round2.question}


def check() -> None:
    (vectors_file,) = sorted(EXPERIMENT.glob("vectors-*.json"))
    (compare_file,) = sorted(EXPERIMENT.glob("compare-*.json"))
    record = json.loads(vectors_file.read_text(encoding="utf-8"))
    compared = json.loads(compare_file.read_text(encoding="utf-8"))
    chunks = jsonl_to_chunks(RULES_CHUNKS.read_text(encoding="utf-8"))
    vectors = load_embeddings(RULES_EMBEDDINGS, chunks, "gemini-embedding-001")
    saved = SavedVectors(record)
    present = RulesRetriever(chunks, vectors, saved)
    same = WeightedRulesRetriever(chunks, vectors, saved, 1.0)
    candidate = WeightedRulesRetriever(chunks, vectors, saved, BM25_WEIGHT)
    expected = {s["query"]: s["top"]["candidate (vector 2, BM25 1)"] for s in compared["searches"]}
    for query in record["queries"]:
        assert [(r.chunk.chunk_id, r.score) for r in same.search(query, TOP_K)] == [
            (r.chunk.chunk_id, r.score) for r in present.search(query, TOP_K)], query
        assert [r.chunk.chunk_id for r in candidate.search(query, TOP_K)] == expected[query], query
    print(f"{len(record['queries'])} queries: weight 1 gives RulesRetriever's results; weight {BM25_WEIGHT} gives "
          f"R68's candidate top {TOP_K}. Nothing sent. Cases: {questions()}")


def ask_cases(agent, retriever, cases: dict[str, str], chat, embedding, meta: dict, out: Path, stamp: str) -> None:
    """Ask each case once on a new thread, saving it as soon as it ends, and stop after a case whose tools failed
    or whose run raised. A case is complete when it returned an answer that finished with `STOP` and no tool error."""
    for case, question in cases.items():
        chat_start, embedding_start = len(chat.attempts), len(embedding.attempts)
        record = meta | {"case": case, "why": CASES[case][1], "question": question, "returned": False,
                         "complete": False}
        agent.reset()  # the thread of this case only, even when its first step fails
        tool_errors = []
        try:
            found = retriever.search(question, TOP_K)
            record["candidate_top_k_for_the_question"] = [chunk_block(r.chunk) for r in found]
            reply = agent.ask(question)
            tool_errors = [{"name": c.name, "error": c.error} for c in reply.tool_calls if c.error]
            record |= {
                "returned": True,
                "answered": reply.answered,
                "finish_reason": reply.finish_reason,
                "tool_errors": tool_errors,
                "complete": reply.answered and reply.finish_reason == "STOP" and not tool_errors,
                "answer": reply.text,
                "agent_contexts": agent_contexts(reply),
                "tool_calls": [{"name": c.name, "arguments": c.arguments, "pages": c.pages, "error": c.error}
                               for c in reply.tool_calls],
                "trace": reply.trace.to_dict(),
            }
        except BaseException as error:
            record |= {"error": f"{type(error).__name__}: {error}", "trace": agent.trace().to_dict()}
            raise
        finally:
            record["chat_attempts"] = chat.attempts[chat_start:]
            record["embedding_attempts"] = embedding.attempts[embedding_start:]
            path = out / f"case-{case}-{stamp}.json"
            path.write_text(json.dumps(record, ensure_ascii=False, indent=1, default=str) + "\n",
                            encoding="utf-8", newline="\n")
            print(f"{case}: complete {record['complete']}, chat {[a['status'] for a in record['chat_attempts']]}, "
                  f"embedding {[a['status'] for a in record['embedding_attempts']]} -> {path.name}")
        if tool_errors:
            print(f"{case}: a tool failed; the next cases are not asked")
            return


def run(chat_budget: int, embedding_budget: int) -> None:
    git = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True)
    if git.returncode != 0 or not git.stdout.strip():
        sys.exit(f"the commit cannot be read: {git.stderr.strip()}; nothing is sent")
    settings = Settings()
    chat = AttemptCounter(RequestBudget(chat_budget, MIN_SECONDS_BETWEEN_CHAT_REQUESTS))
    embedding = AttemptCounter(RequestBudget(embedding_budget, 0))
    chunks = jsonl_to_chunks(RULES_CHUNKS.read_text(encoding="utf-8"))
    embedder = GeminiEmbedder(settings, {"transport": embedding})
    vectors = load_embeddings(RULES_EMBEDDINGS, chunks, embedder.model)
    retriever = WeightedRulesRetriever(chunks, vectors, embedder, BM25_WEIGHT)
    agent = ChatAgent(
        create_chat_model(settings, {"transport": chat}),
        retriever,
        SqlRetriever(CLEAN_DB, SQL_MAX_ROWS),
        build_system_prompt(SQL_SCHEMA.read_text(encoding="utf-8")),
    )
    meta = {"code": git.stdout.strip(), "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "bm25_weight": BM25_WEIGHT, "top_k": TOP_K, "rrf_k": RRF_K,
            "chat_model": settings.chat_model, "embedding_model": settings.embedding_model,
            "index": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in (RULES_CHUNKS, RULES_EMBEDDINGS)}}
    ask_cases(agent, retriever, questions(), chat, embedding, meta, HERE, time.strftime("%Y%m%d-%H%M%S"))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--check", action="store_true", help="check the retriever offline; nothing is sent")
    parser.add_argument("--chat-budget", type=int, help="the most chat requests, retries included")
    parser.add_argument("--embedding-budget", type=int, help="the most embedding requests, retries included")
    parser.add_argument("--send", action="store_true", help="ask the three cases once each")
    args = parser.parse_args()
    if args.check:
        check()
    elif args.send:
        if args.chat_budget is None or args.embedding_budget is None:
            parser.error("--send needs --chat-budget and --embedding-budget")
        run(args.chat_budget, args.embedding_budget)
    else:
        parser.error("give --check, or --send with the budgets")


if __name__ == "__main__":
    main()
