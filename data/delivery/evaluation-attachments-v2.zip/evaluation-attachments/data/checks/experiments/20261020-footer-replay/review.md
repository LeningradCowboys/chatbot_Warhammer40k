# Human review of the footer replay (plan R72)

Replies: `replies-20261020-104748.jsonl`, manifest `manifest-20261020-104748.json`. All 16 calls `answered` (one
attempt each, 200, `STOP`); no `tool_call`, empty, error or not-run call. Both arms had the same system prompt and
messages, but for the text of the `search_rules` tool messages, which the `footers` arm received with each page's
running footer (R71). Each reply was read against its fixed contexts, by the criteria of `proposal.md`, as corrected
in review. "1 / 2" are the two replies of an arm.

| Sample | Criterion | Present (no footers) | Footers |
|---|---|---|---|
| R69 (the scoring rule `0243` in the contexts) | Capture and Control said to belong to the Only War mission | no / no | yes / yes ("In the 'ONLY WAR' mission", "In the "Only War" mission") |
| | not a rule of every game, no unsupported standing | yes / no ("the primary way") | yes / yes |
| | Only War not called the only mission (not in these contexts) | yes / yes | yes / yes |
| | recorded: other ways to score inferred from p. 57 | in both | in both ("other missions may have different scoring methods"; "can vary depending on the mission") |
| | recorded: the rule of victory | not given / incomplete | not given / whole |
| R61 (no scoring rule in the contexts) | no scoring content it did not receive | yes / yes | yes / yes |
| | the rule of victory may be tied to Only War (not required) | not done | not done |
| | recorded: the ways to score said to be absent from the Core Rules | in both | in both |
| | recorded: new defects | none | 2: missions said to be "found in other publications such as Codexes and the Munitorum Field Manual", while p. 55 places units' points values there: an unsupported link |
| round 2 `q007` (regression) | the eligibility to charge, whole; no rule given the scope of a footer | yes / yes | yes / yes |
| round 2 `q011` (regression) | a test for every model before moving; 1–2 destroys a model; no shooting or charging after Falling Back | no (the last left out) / yes | yes / yes |
| | recorded: new defects | none | 1: moving over enemy models said to take "an additional Desperate Escape test", while the context (`0050`) says that the same model can only ever trigger one a phase. 2: says that Stratagems cannot be used on the Battle-shocked unit, without Insane Bravery: supported by the context, and that exception is used just after a failed Battle-shock test in the Command phase, not when Falling Back, so for this question leaving it out is not an error (an exception that is given must keep its conditions) |

Recorded, not judged: citation forms and pages.

Outcome. The mission a rule belongs to reached the context: on R69's fixed contexts, the footers arm named Only War
in both replies, the present arm in neither, and no reply called it the only mission or made it a rule of every
game. No error was seen of a footer's part of the book taken for a rule's scope; this is not to say that the footers
have no other effect. The footers arm had an unsupported link to other publications and a repeated Desperate Escape
test; errors of the same kinds were seen before in answers without footers, and these samples cannot tell whether
the footers bore on them this time. Other defects persisted in both arms (p. 57's inference, the absence claimed).
Two replies per arm and sample show what happened on these contexts, not a stable effect; the whole chat, whose
later searches or ending may change once its tool results carry footers, was not run.
