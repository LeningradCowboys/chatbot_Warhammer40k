"""Replay of saved answers on their fixed contexts, with and without the page footers of R71.

Run from the repository root:

    uv run python data/checks/experiments/20261020-footer-replay/replay.py --check
    uv run python data/checks/experiments/20261020-footer-replay/replay.py --reps 2 --chat-budget 20 --send

Each sample is a saved trace whose last model call wrote the answer. That call is rebuilt as the trace stores it
(`RunTrace.model_input`), with the present system prompt (the trace's, checked equal to the current one) in both
arms. The `present` arm sends the saved messages as they are: their chunks read back without footers, and the
saved tool messages are checked to equal those chunks rendered again by `chunk_block`. The `footers` arm sends the
same messages but for the text of each `search_rules` tool message, rendered again from the same chunks given the
footers of the current chunk file (every other field of each chunk checked equal to the saved one); the new text
is checked to differ from the saved one by the footers only. The model, its settings and its bound tools are the
agent's (checked equal to the trace's); the call streams as the agent's does. No tool is run and nothing is
embedded: a reply that asks for a tool is saved as it is.

Before any request, `manifest-<time>.json` records what will be sent: the source files and their SHA-256 (the
chunk file's included), both arms' messages, the tools, the system prompt, the model settings, the repetitions,
the order of the calls and the budget. The arms alternate, `--reps` times each; every planned call ends with one
record in `replies-<time>.jsonl`, tied to the manifest by its SHA-256, with its status: `answered` (text, no tool
call, finished with `STOP`), `tool_call`, `empty_or_truncated`, `error` (the call raised; the part received is
kept) or `not_run` (an earlier call raised and the run stopped).

`--check` sends nothing: it builds and checks both arms' messages, and, with a fake model, the manifest, the
records with their statuses, and a stream that breaks after its first chunk (wiring only, not the footers' worth).
"""

import argparse
import hashlib
import json
import re
import subprocess
import sys
import tempfile
import time
from dataclasses import replace
from pathlib import Path

from langchain_core.messages import AIMessage, AIMessageChunk, SystemMessage, ToolMessage, messages_to_dict
from langchain_core.utils.function_calling import convert_to_openai_tool

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT))

from src.rag.chatbot.agent import RunTrace, build_tools, chunk_block  # noqa: E402
from src.rag.chatbot.prompts import build_system_prompt  # noqa: E402
from src.rag.chunker.markdown_chunker import Chunk, jsonl_to_chunks  # noqa: E402
from src.rag.config import RULES_CHUNKS, SQL_SCHEMA, Settings  # noqa: E402
from src.rag.llm.budget import AttemptCounter, RequestBudget  # noqa: E402
from src.rag.llm.gemini import MIN_SECONDS_BETWEEN_CHAT_REQUESTS, create_chat_model  # noqa: E402

# name: (saved file, key of its trace or None)
SAMPLES = {
    "R69-scoring": ("data/checks/experiments/20261019-rrf-retest/case-scoring-20261019-180720.json", "trace"),
    "R61-scoring": ("data/checks/acceptance/20261018-121418_scoring_interactive/trace.json", None),
    "round2-q007": ("data/eval/runs/round2/answers/q007.json", "trace"),
    "round2-q011": ("data/eval/runs/round2/answers/q011.json", "trace"),
}
FOOTER = re.compile(r" \(page footer p\. \d+: [^\n]*\)(?=\n)")  # what `chunk_block` adds to a page line


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def arms_of(trace: RunTrace, current: dict[str, Chunk], present: str) -> dict[str, list]:
    """The last model call's messages as saved, and with the footers; checked as the docstring says."""
    last = trace.model_calls[-1]
    assert last.node == "agent" and last.input_count == len(trace.messages) - 1
    assert trace.system_prompt == present, "the trace's prompt is not the current one"
    saved = trace.model_input(last)[1:]  # without the system prompt, sent apart
    footed = []
    for message in saved:
        if isinstance(message, ToolMessage) and message.name == "search_rules":
            chunks = [Chunk(**item["chunk"]) for item in message.artifact]
            assert all(chunk.page_footers == [] for chunk in chunks)
            assert message.content == "\n\n".join(chunk_block(chunk) for chunk in chunks), "old rendering"
            given = []
            for chunk in chunks:
                now = current[chunk.chunk_id]
                assert replace(now, page_footers=[]) == chunk, f"{chunk.chunk_id} differs beyond footers"
                given.append(now)
            content = "\n\n".join(chunk_block(chunk) for chunk in given)
            assert FOOTER.sub("", content) == message.content, "more than the footers changed"
            footed.append(message.model_copy(update={"content": content}))
        else:
            footed.append(message)
    return {"present": saved, "footers": footed}


def checked_inputs(chat_model, present: str) -> dict[str, dict[str, list]]:
    declarations = [convert_to_openai_tool(t) for t in build_tools(None, None)]
    current = {chunk.chunk_id: chunk for chunk in jsonl_to_chunks(RULES_CHUNKS.read_text(encoding="utf-8"))}
    inputs = {}
    for name, (path, key) in SAMPLES.items():
        data = json.loads((ROOT / path).read_text(encoding="utf-8"))
        trace = RunTrace.from_dict(data[key] if key else data)
        assert trace.tools == declarations, f"{name}: other tools"
        assert trace.model_settings == dict(chat_model._identifying_params), f"{name}: other model settings"
        inputs[name] = arms_of(trace, current, present)
    return inputs


def status(text: str, tool_calls: list, finish_reason: str | None) -> str:
    if tool_calls:
        return "tool_call"
    return "answered" if text and finish_reason == "STOP" else "empty_or_truncated"


def replay(chat_model, inputs: dict[str, dict[str, list]], prompt: str, reps: int, budget: int, counter,
           meta: dict, out_dir: Path, stamp: str) -> tuple[Path, Path]:
    """Write the manifest, then make every planned call in order, one record each; stop at a call that raises."""
    arms = ["present", "footers"]
    order = [(rep, name, arm) for rep in range(1, reps + 1) for name in inputs for arm in arms]
    manifest = meta | {
        "sources": {path: sha256((ROOT / path).read_bytes()) for path, _ in SAMPLES.values()}
        | {str(RULES_CHUNKS.relative_to(ROOT)): sha256(RULES_CHUNKS.read_bytes())},
        "samples": {name: path for name, (path, _) in SAMPLES.items()},
        "messages": {name: {arm: messages_to_dict(m) for arm, m in by_arm.items()} for name, by_arm in inputs.items()},
        "tools": [convert_to_openai_tool(t) for t in build_tools(None, None)],
        "system_prompt": prompt,
        "system_prompt_sha256": sha256(prompt.encode()),
        "model_settings": dict(chat_model._identifying_params),
        "reps": reps,
        "order": order,
        "chat_budget": budget,
    }
    manifest_path = out_dir / f"manifest-{stamp}.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=1) + "\n", encoding="utf-8",
                             newline="\n")
    link = {"manifest": manifest_path.name, "manifest_sha256": sha256(manifest_path.read_bytes())}
    model = chat_model.bind_tools(build_tools(None, None))
    replies_path = out_dir / f"replies-{stamp}.jsonl"
    with replies_path.open("w", encoding="utf-8", newline="\n") as file:

        def save(record: dict) -> None:
            file.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
            file.flush()

        for position, (rep, name, arm) in enumerate(order):
            start = len(counter.attempts)
            record = link | {"position": position, "sample": name, "arm": arm, "rep": rep}
            reply = None
            try:
                for chunk in model.stream([SystemMessage(prompt), *inputs[name][arm]]):
                    reply = chunk if reply is None else reply + chunk
                reply = reply or AIMessageChunk(content="")
                finish = reply.response_metadata.get("finish_reason")
                record |= {"status": status(reply.text, reply.tool_calls, finish), "text": reply.text,
                           "tool_calls": reply.tool_calls, "finish_reason": finish}
            except BaseException as error:
                record |= {"status": "error", "error": f"{type(error).__name__}: {error}",
                           "partial_text": reply.text if reply is not None else ""}
                record["attempts"] = counter.attempts[start:]
                save(record)
                for later, (rep2, name2, arm2) in enumerate(order[position + 1:], start=position + 1):
                    save(link | {"position": later, "sample": name2, "arm": arm2, "rep": rep2, "status": "not_run"})
                print(f"{name} {arm} rep {rep}: error; {len(order) - position - 1} calls not run")
                raise
            record["attempts"] = counter.attempts[start:]
            save(record)
            print(f"{name} {arm} rep {rep}: {record['status']} {[a['status'] for a in record['attempts']]}")
    return manifest_path, replies_path


def check() -> None:
    from tests.fakes import FakeChatModel

    class BreakingChatModel(FakeChatModel):
        """Streams its reply's first chunk, then raises, on the call numbered `breaks_at` (from 1)."""

        breaks_at: int = 0

        def _stream(self, *args, **kwargs):
            for chunk in super()._stream(*args, **kwargs):
                yield chunk
                if len(self.calls) == self.breaks_at:
                    raise ConnectionError("stream broke")

    prompt = build_system_prompt(SQL_SCHEMA.read_text(encoding="utf-8"))
    inputs = checked_inputs(create_chat_model(Settings(), {}), prompt)
    changed = {}
    for name, by_arm in inputs.items():
        pairs = list(zip(by_arm["present"], by_arm["footers"], strict=True))
        assert all(a == b for a, b in pairs if not (isinstance(a, ToolMessage) and a.name == "search_rules"))
        changed[name] = [FOOTER.findall(b.content) for a, b in pairs if a is not b]
    calls = 2 * 2 * len(inputs)
    stop = {"finish_reason": "STOP"}

    def scripted() -> list:
        replies = [AIMessage(f"reply {i}", response_metadata=stop) for i in range(calls)]
        replies[1] = AIMessage("", tool_calls=[{"name": "search_rules", "args": {"query": "q"}, "id": "c1"}])
        replies[2] = AIMessage("", response_metadata=stop)
        replies[3] = [AIMessageChunk(content="part one, "), AIMessageChunk(content="part two",
                                                                          response_metadata=stop)]
        return replies

    with tempfile.TemporaryDirectory() as tmp:
        fake = BreakingChatModel(replies=scripted())
        manifest_path, replies_path = replay(fake, inputs, prompt, 2, 20, AttemptCounter(), {"m": 1}, Path(tmp), "A")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        records = [json.loads(line) for line in replies_path.read_text(encoding="utf-8").splitlines()]
        assert len(manifest["order"]) == calls == len(records)
        assert str(RULES_CHUNKS.relative_to(ROOT)) in manifest["sources"]
        assert all(r["manifest_sha256"] == sha256(manifest_path.read_bytes()) for r in records)
        assert [r["status"] for r in records[:4]] == ["answered", "tool_call", "empty_or_truncated", "answered"]
        for call, record in zip(fake.calls, records, strict=True):
            assert call.messages[0].content == prompt
            assert call.messages[1:] == inputs[record["sample"]][record["arm"]], record["sample"]
        broken = BreakingChatModel(replies=scripted(), breaks_at=4)
        try:
            replay(broken, inputs, prompt, 2, 20, AttemptCounter(), {"m": 1}, Path(tmp), "B")
            raise AssertionError("the broken stream did not raise")
        except ConnectionError:
            pass
        records = [json.loads(line) for line in (Path(tmp) / "replies-B.jsonl").read_text(encoding="utf-8").splitlines()]
        assert [r["status"] for r in records[:4]] == ["answered", "tool_call", "empty_or_truncated", "error"]
        assert records[3]["partial_text"] == "part one, " and {r["status"] for r in records[4:]} == {"not_run"}
        assert len(broken.calls) == 4
    print(f"{len(inputs)} samples: the saved tool messages equal their chunks rendered again; the footers arm "
          f"differs by the footers only, the other messages equal. Footers added per sample and tool message:")
    for name, footers in changed.items():
        print(f"  {name}: {footers}")
    print(f"Fake runs: manifest, {calls} records with their statuses, a broken stream saved as error and the "
          f"rest as not_run. Nothing sent.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--check", action="store_true", help="check offline; nothing is sent")
    parser.add_argument("--reps", type=int, default=2, help="replies per sample and arm")
    parser.add_argument("--chat-budget", type=int, help="the most chat requests, retries included")
    parser.add_argument("--send", action="store_true", help="replay on the API")
    args = parser.parse_args()
    if args.check:
        check()
        return
    if not args.send or args.chat_budget is None:
        parser.error("give --check, or --send with --chat-budget")
    git = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True)
    if git.returncode != 0 or not git.stdout.strip():
        sys.exit(f"the commit cannot be read: {git.stderr.strip()}; nothing is sent")
    prompt = build_system_prompt(SQL_SCHEMA.read_text(encoding="utf-8"))
    counter = AttemptCounter(RequestBudget(args.chat_budget, MIN_SECONDS_BETWEEN_CHAT_REQUESTS))
    chat_model = create_chat_model(Settings(), {"transport": counter})
    inputs = checked_inputs(chat_model, prompt)
    meta = {"code": git.stdout.strip(), "script_sha256": sha256(Path(__file__).read_bytes())}
    _, replies_path = replay(chat_model, inputs, prompt, args.reps, args.chat_budget, counter, meta, HERE,
                             time.strftime("%Y%m%d-%H%M%S"))
    print(f"-> {replies_path.name}")


if __name__ == "__main__":
    main()
