# 回答失败样本分析与提示修订提案（第二版，离线，待审）

2026-10-20。只读了保存的回答、trace、chunk 和代码；没有修改正式提示，没有调用 API。

## 1. 本轮范围：证据边界、无依据推断、条件和时机

| # | 样本 | 现象 | 原文 / 上下文 | 归类 |
|---|---|---|---|---|
| C1 | 得分方式（R61） | 一次检索没找到，就说 "not present in the Core Rules document"；判胜规则只讲了"VP 多者获胜" | p.60："if one army has been destroyed … Otherwise, the most VP …" | 把"没检索到"说成"文档里没有"；条件丢失 |
| C2 | 得分方式（R69 复测） | 从 p.57 推出 "missions provide further ways to score" | p.57 只写了："Each mission will tell you what you need to do in order to win" | 无依据推断 |
| B1 | 第二轮 q006 | Insane Bravery 作为例外，没有写使用条件 | p.42 在上下文里，写有 "just after you have failed a Battle-shock test" | 例外缺条件 |
| B2 | 第二轮 q010 | 先说"每个 Stratagem 同阶段只能用一次"，接着又说 "you can use different Stratagems multiple times within the same phase"；没讲 CP 不足就不能用 | p.41 写有：CP 不够时不能用；同一个 Stratagem 同一阶段不能超过一次 | 表述有歧义，限制说明不足（不认定为已确认的逻辑反推错误） |

另外两个样本也属于这一类，但这次不放进回放：
- 第一轮 q002：Feel No Pain 的时机写错；
- R62 的 Stratagem 验收："谁的指挥阶段"写得含糊。

原因是：回放样本只留每类的代表，加上两个回归对照，样本数控制在 6 个。如果这一轮有明确收益，再把这两个加进端到端复测。

## 2. 记录下来，这一轮不处理

- **引用格式**：两轮 13 份回答里有 5 处一个括号写了好几页（第二轮 q002、q004、q006）；被引用的页码全部都在当次收到的上下文里。
- **q006 的引用页不对**：Insane Bravery 引到了 p.11，实际在 p.42，而 p.42 也在上下文里。回放时会记下这一点，但这一轮不改引用规则。
- **R45 的数据库和混合来源缺陷**：引用格式写成 `[DB: 行]`、版本或来源没写、漏了另一个 profile、Grenade 的无依据能力关联。这一轮不处理，原因和修法都还没确认。
- **任务归属的上下文缺失（D1）**：0243 的 section 只有 `CAPTURE AND CONTROL`，正文里也没有 Only War；解析结果里有这一层（`##### ONLY WAR` → … → `############# CAPTURE AND CONTROL`），是 chunker 的命名规则（用最少的上级标题来区分）把它省掉了。
  - 修法要先分清两种方案：一种是改嵌入的文本，另一种是只补充给模型看的元数据。这一轮不展开。
  - 这一轮的验收仍然要求：回答不能虚构所属任务，也不能把得分规则说成所有对局的通则。

## 3. 候选修改（只在回放脚本里拼出来，不改 `ANSWER_RULES`）

**(1) 第一条后面补一句**：

> … say "I could not find this" and what you looked for: that your searches did not find something does not show that the rulebook lacks it. Never invent …

**(2) 新增一条**（采用你给的措辞，不举 Stratagem 的例子）：

> - Draw conclusions only when the tool results support them. Do not infer permission merely from the absence of a prohibition, generalise beyond a rule's stated scope, or connect rules without supporting evidence.

**(3) 新增"条件"一条**（允许说"证据不足以判断"；允许准确转述或翻译）：

> - Conditions: give a rule with the conditions and limits the results state for it (who, when, on what, at what cost). Give an exception with its own conditions, and say whether they fit the case asked, or that the results are not enough to tell. Keep who acts and when exactly as the rule states them, in a close paraphrase or translation.

(2) 和 (3) 都插在 "printed as dice graphics." 这一句后面，也就是在引用规则之前。其余规则一字不改。

## 4. 回放设计：固定上下文，只换提示

脚本：`replay.py`（同目录）。

- **运行清单**：发出任何请求之前，先写好 `manifest-<time>.json`。里面记录：
  - 六份来源文件的路径和 SHA-256；
  - 实际重建的消息、工具声明，以及两份完整的系统提示；
  - 模型参数、重复次数、调用顺序和预算。

  每条回复都通过清单的 SHA-256 关联到这份清单。
- **中断保存**：如果流式回复中途出错，已收到的部分内容和错误一起保存，状态记为 `error`；之后计划内的调用全部记为 `not_run`，然后停止，不再发出任何调用。

- **6 份样本**：
  - 失败样本：R61 得分方式、R69 得分方式、第二轮 q006、第二轮 q010；
  - 回归对照：第二轮 q007、q011。

  每份都取保存的 trace 里最后一次模型调用，也就是写出回答的那一次。用 `RunTrace.model_input` 原样重建它的输入：问题、模型自己发出的工具调用，以及当时收到的工具结果。
- **离线核实过**：6 份样本的最后一次调用都是 `agent` 节点；保存的系统提示、工具声明和模型参数，都和当前版本完全一致（gemini-2.5-flash，温度 0.7）。
- **两组**：
  - 现行组用 trace 里保存的系统提示（就是当前的提示）；
  - 候选组只替换上面 (1)–(3) 三处。

  脚本会检查：把候选提示的改动换回去，得到的文本和现行提示完全相同。

  模型、参数和绑定的工具都和 agent 一样，调用方式也和 agent 一样用流式。
- **不执行任何工具，不做任何 embedding**。如果模型的回复是再调用一次工具，就原样记下来，单独统计，不当作失败，比如 R61 那份候选组可能会选择再检索一次。
- **每组每份样本回答 2 次**，两组交替进行，共 24 次聊天请求。每条回复一到就立即保存。
- **离线检查**（`--check`）已经通过，用的是假模型：
  - 清单里有两份完整的提示、来源文件和调用顺序，24 条记录都关联到这份清单；
  - 记录按顺序保存，`answered`、`tool_call`、`empty_or_truncated` 三种状态都判对了，分两段到达的回复能完整拼接；
  - 模拟"先收到第一段内容、随后抛错"：之前的记录都在，这一条记为 `error`，部分内容 `"part one, "` 也保存了，其余 20 条记为 `not_run`，并且之后没有再发出调用。

  这只验证了接线和保存，不能说明提示有没有效果。

## 5. 逐项标准（运行前定下，由人逐条阅读判断）

| 样本 | 标准 |
|---|---|
| R61 得分方式（上下文里没有计分规则） | 不说 Core Rules 或规则书里没有，而是说这次检索没找到；判胜规则如果提到，要完整（全军覆没的条件，以及"否则"）；不虚构所属任务，也不当成所有对局的通则。要求再检索一次的回复单独记录 |
| R69 得分方式（上下文里有 0243） | Capture and Control 带上它的条件（从第二轮开始、在指挥阶段结束时、当前回合的玩家、每个目标点 1 VP、每回合最多 3 VP）；不从 p.57 推出其他得分方式；不虚构任务，也不当成通则；判胜规则如果提到，要完整 |
| 第二轮 q006 | 核心内容保持：撤退后不能冲锋；Battle-shocked 单位撤退时，**每个模型**都要做 Desperate Escape 测试（只写“需要测试”不算）；Insane Bravery 如果提到，要带上条件，并说明它适不适用于这个撤退情境，或者说证据不足以判断。引用页另外记录，不作判断依据 |
| 第二轮 q010 | 不出现"不同 Stratagem 同一阶段可以多次使用"这类有歧义的说法；讲出同一个 Stratagem 同一阶段只能用一次、要支付 CP、CP 不足就不能用；CP 的来源保持完整 |
| 第二轮 q007、q011（回归） | 人工审核时判为正确的核心内容都还在（q007 是冲锋资格；q011 是移动前**每个模型**都要测试，不能只写“需要测试”；掷出 1–2 摧毁一个模型；撤退后不能射击和冲锋）；没有新增无依据的说法；没有变得过度保守（比如不该说"找不到"的地方说了找不到） |

**每次调用的状态**：每组每份样本 2 次，计划内的 24 次调用各有一个明确的状态，不从分母里删掉任何一项。
- `answered`：正常完成的文本回答；
- `tool_call`：要求继续调用工具。不直接判错，但也不算修复成功；
- `empty_or_truncated`：空回答、被截断，或者结束原因不是 `STOP`；
- `error`：调用中途出错，已收到的部分内容保留；
- `not_run`：前面的调用出错、运行停止，所以没有运行。

**判定**：
- 逐样本列出两组各两次回复的情况：哪些标准满足了、哪些没完成（按上面的状态），以及新出现的缺陷。然后再判断值不值得做端到端复测。
- "明显更好"不是统计显著的意思：每组每份只有 2 次，结论只能说明在这些固定上下文里出现了什么。
- 不能靠少回答、不回答来提高通过率：遇到 `tool_call`、"I could not find this"，或者该给的内容没给，都要逐条写明，不能当作满足了标准。

## 6. 申请（待审）

```
uv run python data/checks/experiments/20261020-prompt-revision/replay.py --reps 2 --chat-budget 28 --send
```

- 需要 24 次聊天请求，上限设为 28，留出 4 次给重试；重试计入上限，用完就停。0 次 embedding。
- 只启动一次，不追加，不重新启动，不跑 RAGAS。
