# Human review of the replay (plan R70)

Replies: `replies-20261020-092424.jsonl`, manifest `manifest-20261020-092424.json`. All 24 calls `answered`
(one attempt each, 200, `STOP`); no `tool_call`, empty, error or not-run call. Each reply was read against the
sample's tool results (the fixed contexts). Criteria as set before the run (`proposal.md` §5), corrected in review
where noted. "1 / 2" are the two replies of an arm.

| Sample | Criterion | Present | Candidate |
|---|---|---|---|
| R61 ways to score (no scoring rule in the contexts) | does not say the rulebook lacks the ways to score | no / no ("the Core Rules do not detail …") | no / no ("The Core Rules do not specify …") |
| | rule of victory, if given, whole (destroyed army, otherwise, tie) | partial ("unless one army has been destroyed", not who wins) / no | yes / yes |
| | new defects | none | 2: "found in … Codexes and the Munitorum Field Manual [p. 55]": p. 55 says that units' points values are found there, not ways to score; an unsupported link |
| R69 ways to score (`0243` in the contexts) | `CAPTURE AND CONTROL` with its conditions | yes / yes | yes / yes |
| | no other ways to score inferred from p. 57 | no / no | no / no (1 hedged with "implying", the same inference) |
| | no invented scope, not a rule of every game | no ("ways to score points in Warhammer 40,000") / no ("the primary way" in the Core Rules, unsupported) | no ("the primary way", unsupported) / no ("In the standard game", invented) |
| round 2 `q006` | core: no charge after Falling Back; a Desperate Escape test for every model | yes / yes | yes / yes (1 adds, rightly, no shooting after Falling Back) |
| | Insane Bravery, if given, with its condition, or that the results cannot tell whether it fits | no / no | no / no |
| round 2 `q010` | the same Stratagem at most once in a phase | yes / yes | yes / yes |
| | no suggestion that the same Stratagem may be repeated in a phase | yes / yes ("no explicit limit on how many *different* Stratagems": right only as "the rules given list no single cap", not as "no limit") | no ("different Stratagems multiple times within that phase", ambiguous) / yes |
| | the CP cost, and no Stratagem without enough CP | no / no | no / no |
| | whose Command phase, as p. 11 states it | no ("their") / yes ("your") | no / no ("their") |
| round 2 `q007` (regression) | the eligibility to charge, whole; no new defect | yes / yes | yes / yes |
| round 2 `q011` (regression) | a test for every model before moving; 1–2 destroys a model; no shooting or charging after Falling Back | yes / yes | yes / yes |
| | new defects | 2: moving over enemy models said to trigger "additional Desperate Escape tests", while the context (`0050`) says that the same model can only ever trigger one a phase | none (2 states that rule rightly) |

Recorded, not judged in this round: citations not in form in both arms (`p. 14, p. 29`; `p. 19, 29`); the present
arm's `q011` 2 cites Insane Bravery's timing to p. 11, which p. 42 holds.

Outcome: local gains (R61's rule of victory whole in both candidate replies; `q011`'s added error avoided by the
candidate), persisting failures (the absence of the ways to score claimed, p. 57's inference, Insane Bravery without
its condition, `q010`'s CP limits, in both arms), and new errors in the candidate (an unsupported link to the
Munitorum Field Manual, an invented "standard game"). Two replies per arm and sample show what happened on these
contexts, not a stable effect. Not adopted.
