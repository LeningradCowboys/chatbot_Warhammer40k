"""Replay of saved answers on their fixed contexts, under the present prompt and the candidate one.

Run from the repository root:

    uv run python data/checks/experiments/20261020-prompt-revision/replay.py --check
    uv run python data/checks/experiments/20261020-prompt-revision/replay.py --reps 2 --chat-budget 28 --send

Each sample is a saved trace whose last model call wrote the answer. That call is rebuilt as the trace stores it
(`RunTrace.model_input`: the system prompt, the question, the model's tool calls and the tool results it received),
and only its system prompt changes: the present one, which the trace holds (checked equal to the current one), or
the candidate, the same text with the bullets of `CHANGES` replaced. The model, its settings and its bound tools are
the agent's (checked equal to the trace's); the call streams as the agent's does. No tool is run and nothing is
embedded: a reply that asks for a tool is saved as it is.

Before any request, `manifest-<time>.json` records what will be sent: the source files and their SHA-256, the
rebuilt messages, the tool declarations, both system prompts in full, the model settings, the repetitions, the order
of the calls and the budget. The two arms alternate, `--reps` times each; every planned call ends with one record in
`replies-<time>.jsonl`, tied to the manifest by its SHA-256 and written as soon as it ends, with its status:
`answered` (text, no tool call, finished with `STOP`), `tool_call` (asks for a tool), `empty_or_truncated` (no text,
or another finish reason), `error` (the call raised; the part received is kept) or `not_run` (not called, since an
earlier call raised and the run stopped).

`--check` sends nothing: it checks the samples' traces, that the candidate differs from the present prompt by the
changes only, and, with a fake model, the manifest, the records in order with their statuses, and a stream that
breaks after its first chunk (wiring only, not the prompt's worth).
"""

import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from langchain_core.messages import AIMessage, AIMessageChunk, SystemMessage, messages_to_dict
from langchain_core.utils.function_calling import convert_to_openai_tool

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT))

from src.rag.chatbot.agent import RunTrace, build_tools  # noqa: E402
from src.rag.chatbot.prompts import build_system_prompt  # noqa: E402
from src.rag.config import SQL_SCHEMA, Settings  # noqa: E402
from src.rag.llm.budget import AttemptCounter, RequestBudget  # noqa: E402
from src.rag.llm.gemini import MIN_SECONDS_BETWEEN_CHAT_REQUESTS, create_chat_model  # noqa: E402

# name: (saved file, key of its trace or None)
SAMPLES = {
    "R61-scoring": ("data/checks/acceptance/20261018-121418_scoring_interactive/trace.json", None),
    "R69-scoring": ("data/checks/experiments/20261019-rrf-retest/case-scoring-20261019-180720.json", "trace"),
    "round2-q006": ("data/eval/runs/round2/answers/q006.json", "trace"),
    "round2-q010": ("data/eval/runs/round2/answers/q010.json", "trace"),
    "round2-q007": ("data/eval/runs/round2/answers/q007.json", "trace"),
    "round2-q011": ("data/eval/runs/round2/answers/q011.json", "trace"),
}
# (present text, candidate text): evidence boundaries, unsupported inference, conditions and timing
CHANGES = [
    (
        'say "I could not find this" and what you looked for. Never invent',
        'say "I could not find this" and what you looked for: that your searches did not find something does '
        "not show that the rulebook lacks it. Never invent",
    ),
    (
        "printed as dice graphics.\n",
        "printed as dice graphics.\n"
        "- Draw conclusions only when the tool results support them. Do not infer permission merely from "
        "the absence of a prohibition, generalise beyond a rule's stated scope, or connect rules without "
        "supporting evidence.\n"
        "- Conditions: give a rule with the conditions and limits the results state for it (who, when, on "
        "what, at what cost). Give an exception with its own conditions, and say whether they fit the case "
        "asked, or that the results are not enough to tell. Keep who acts and when exactly as the rule "
        "states them, in a close paraphrase or translation.\n",
    ),
]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def prompts() -> dict[str, str]:
    """The two arms' system prompts: the present one and the candidate."""
    present = build_system_prompt(SQL_SCHEMA.read_text(encoding="utf-8"))
    candidate = present
    for old, new in CHANGES:
        assert candidate.count(old) == 1, old
        candidate = candidate.replace(old, new)
    return {"present": present, "candidate": candidate}


def checked_inputs(chat_model, present: str) -> dict[str, list]:
    """Each sample's last model call as the trace stores it, after checking that it can be replayed."""
    declarations = [convert_to_openai_tool(t) for t in build_tools(None, None)]
    inputs = {}
    for name, (path, key) in SAMPLES.items():
        data = json.loads((ROOT / path).read_text(encoding="utf-8"))
        trace = RunTrace.from_dict(data[key] if key else data)
        last = trace.model_calls[-1]
        assert last.node == "agent" and last.input_count == len(trace.messages) - 1, name
        assert trace.system_prompt == present, f"{name}: the trace's prompt is not the current one"
        assert trace.tools == declarations, f"{name}: other tools"
        assert trace.model_settings == dict(chat_model._identifying_params), f"{name}: other model settings"
        inputs[name] = trace.model_input(last)
    return inputs


def status(text: str, tool_calls: list, finish_reason: str | None) -> str:
    if tool_calls:
        return "tool_call"
    return "answered" if text and finish_reason == "STOP" else "empty_or_truncated"


def replay(chat_model, inputs: dict[str, list], arms: dict[str, str], reps: int, budget: int, counter,
           meta: dict, out_dir: Path, stamp: str) -> tuple[Path, Path]:
    """Write the manifest, then make every planned call in order, one record each; stop at a call that raises."""
    order = [(rep, name, arm) for rep in range(1, reps + 1) for name in inputs for arm in arms]
    manifest = meta | {
        "sources": {path: sha256((ROOT / path).read_bytes()) for path, _ in SAMPLES.values()},
        "samples": {name: path for name, (path, _) in SAMPLES.items()},
        "messages": {name: messages_to_dict(messages[1:]) for name, messages in inputs.items()},
        "tools": [convert_to_openai_tool(t) for t in build_tools(None, None)],
        "system_prompts": arms,
        "system_prompt_sha256": {arm: sha256(prompt.encode()) for arm, prompt in arms.items()},
        "model_settings": dict(chat_model._identifying_params),
        "reps": reps,
        "order": order,
        "chat_budget": budget,
    }
    manifest_path = out_dir / f"manifest-{stamp}.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=1) + "\n", encoding="utf-8",
                             newline="\n")
    link = {"manifest": manifest_path.name, "manifest_sha256": sha256(manifest_path.read_bytes())}
    model = chat_model.bind_tools(build_tools(None, None))
    replies_path = out_dir / f"replies-{stamp}.jsonl"
    with replies_path.open("w", encoding="utf-8", newline="\n") as file:

        def save(record: dict) -> None:
            file.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
            file.flush()

        for position, (rep, name, arm) in enumerate(order):
            start = len(counter.attempts)
            record = link | {"position": position, "sample": name, "arm": arm, "rep": rep}
            reply = None
            try:
                for chunk in model.stream([SystemMessage(arms[arm]), *inputs[name][1:]]):
                    reply = chunk if reply is None else reply + chunk
                reply = reply or AIMessageChunk(content="")
                finish = reply.response_metadata.get("finish_reason")
                record |= {"status": status(reply.text, reply.tool_calls, finish), "text": reply.text,
                           "tool_calls": reply.tool_calls, "finish_reason": finish}
            except BaseException as error:
                record |= {"status": "error", "error": f"{type(error).__name__}: {error}",
                           "partial_text": reply.text if reply is not None else ""}
                record["attempts"] = counter.attempts[start:]
                save(record)
                for later, (rep2, name2, arm2) in enumerate(order[position + 1:], start=position + 1):
                    save(link | {"position": later, "sample": name2, "arm": arm2, "rep": rep2, "status": "not_run"})
                print(f"{name} {arm} rep {rep}: error; {len(order) - position - 1} calls not run")
                raise
            record["attempts"] = counter.attempts[start:]
            save(record)
            print(f"{name} {arm} rep {rep}: {record['status']} {[a['status'] for a in record['attempts']]}")
    return manifest_path, replies_path


def check() -> None:
    from tests.fakes import FakeChatModel

    class BreakingChatModel(FakeChatModel):
        """Streams its reply's first chunk, then raises, on the call numbered `breaks_at` (from 1)."""

        breaks_at: int = 0

        def _stream(self, *args, **kwargs):
            for chunk in super()._stream(*args, **kwargs):
                yield chunk
                if len(self.calls) == self.breaks_at:
                    raise ConnectionError("stream broke")

    arms = prompts()
    present, candidate = arms["present"], arms["candidate"]
    rebuilt = candidate
    for old, new in CHANGES:
        rebuilt = rebuilt.replace(new, old)
    assert candidate != present and rebuilt == present, "the candidate differs by more than its changes"
    inputs = checked_inputs(create_chat_model(Settings(), {}), present)
    calls = 2 * len(arms) * len(inputs)
    stop = {"finish_reason": "STOP"}

    def scripted() -> list:
        replies = [AIMessage(f"reply {i}", response_metadata=stop) for i in range(calls)]
        replies[1] = AIMessage("", tool_calls=[{"name": "search_rules", "args": {"query": "q"}, "id": "c1"}])
        replies[2] = AIMessage("", response_metadata=stop)
        replies[3] = [AIMessageChunk(content="part one, "), AIMessageChunk(content="part two",
                                                                          response_metadata=stop)]
        return replies

    with tempfile.TemporaryDirectory() as tmp:
        fake = BreakingChatModel(replies=scripted())
        manifest_path, replies_path = replay(fake, inputs, arms, 2, 28, AttemptCounter(), {"m": 1}, Path(tmp), "A")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        records = [json.loads(line) for line in replies_path.read_text(encoding="utf-8").splitlines()]
        assert manifest["system_prompts"] == arms and len(manifest["order"]) == calls == len(records)
        assert set(manifest["sources"]) == {path for path, _ in SAMPLES.values()}
        assert all(r["manifest_sha256"] == sha256(manifest_path.read_bytes()) for r in records)
        assert [r["status"] for r in records[:4]] == ["answered", "tool_call", "empty_or_truncated", "answered"]
        assert records[3]["text"] == "part one, part two"
        for call, record in zip(fake.calls, records, strict=True):
            assert call.messages[0].content == arms[record["arm"]]
            assert call.messages[1:] == inputs[record["sample"]][1:], record["sample"]

        broken = BreakingChatModel(replies=scripted(), breaks_at=4)
        try:
            replay(broken, inputs, arms, 2, 28, AttemptCounter(), {"m": 1}, Path(tmp), "B")
            raise AssertionError("the broken stream did not raise")
        except ConnectionError:
            pass
        records = [json.loads(line) for line in (Path(tmp) / "replies-B.jsonl").read_text(encoding="utf-8").splitlines()]
        assert [r["status"] for r in records[:4]] == ["answered", "tool_call", "empty_or_truncated", "error"]
        assert records[3]["partial_text"] == "part one, " and "stream broke" in records[3]["error"]
        assert {r["status"] for r in records[4:]} == {"not_run"} and len(records) == calls
        assert len(broken.calls) == 4, "a call was made after the stream broke"
    print(f"{len(inputs)} samples replayable; the candidate differs by its {len(CHANGES)} changes only "
          f"({len(present)} -> {len(candidate)} characters). Fake runs: the manifest holds both prompts, the "
          f"sources and the order; {calls} records in order, each tied to the manifest, with the statuses "
          f"answered, tool_call, empty_or_truncated; a stream broken after its first chunk saves its part as "
          f"error, the {calls - 4} later calls as not_run, and no call follows. Nothing sent.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--check", action="store_true", help="check offline; nothing is sent")
    parser.add_argument("--reps", type=int, default=2, help="replies per sample and arm")
    parser.add_argument("--chat-budget", type=int, help="the most chat requests, retries included")
    parser.add_argument("--send", action="store_true", help="replay on the API")
    args = parser.parse_args()
    if args.check:
        check()
        return
    if not args.send or args.chat_budget is None:
        parser.error("give --check, or --send with --chat-budget")
    git = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True)
    if git.returncode != 0 or not git.stdout.strip():
        sys.exit(f"the commit cannot be read: {git.stderr.strip()}; nothing is sent")
    arms = prompts()
    counter = AttemptCounter(RequestBudget(args.chat_budget, MIN_SECONDS_BETWEEN_CHAT_REQUESTS))
    chat_model = create_chat_model(Settings(), {"transport": counter})
    inputs = checked_inputs(chat_model, arms["present"])
    meta = {"code": git.stdout.strip(), "script_sha256": sha256(Path(__file__).read_bytes())}
    _, replies_path = replay(chat_model, inputs, arms, args.reps, args.chat_budget, counter, meta, HERE,
                             time.strftime("%Y%m%d-%H%M%S"))
    print(f"-> {replies_path.name}")


if __name__ == "__main__":
    main()
