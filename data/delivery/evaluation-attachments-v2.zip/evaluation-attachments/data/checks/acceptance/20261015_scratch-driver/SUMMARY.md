# Online acceptance, steps 5-6 — 2026-10-15 (gemini-2.5-flash, gemini-embedding-001)

Driver: drive.py (CLI's own build_agent / chat_loop; chat attempts capped by RequestBudget, 12 s apart).
Lines per run: <question>, /sources, /reset, /sources, /quit. Simulated terminal console (TERM=xterm-256color).

| # | Mode | Question | Chat attempts | Embed attempts | Tools | Result |
|---|---|---|---|---|---|---|
| q1 | interactive | What is the rule for grenades? | 2 (200, 200) | 1 (200) | search_rules "Grenades" -> pp. 42, 46, 26, 45 | Correct, cited [Core Rules p. 42]. Deviation: no run_sql, so no DB version (plan §7 expects both). |
| q2 | interactive | What are the different ways to score points? | 3 (200 x3) | 2 (200 x2) | search_rules x2 -> pp. 55, 3, 60 / 57, 59, 60 | PARTLY WRONG: p. 59 objective markers ("for example", one mission) and p. 3/57 primary objectives are in the chunks; but "destroying the enemy army" is listed as a way of scoring, while p. 60 decides the victor and gives no VP. Other paragraphs name no mission. |
| q3 | interactive | What is the toughness of a space marine? | 1 (200) | 0 | none | FAIL: asked the user which unit, no tool called; the prompt's "Categories" rule says to resolve and answer. Run stopped here. |
| q4 | --question | How can I use a stratagem? | not run | not run | | stopped after q3's failure |

CLI checks that passed in q1-q3: streamed text and status lines drawn, only the final answer left (Markdown);
/sources lists tool, query, pages ("No tool was called" for q3); /reset then /sources gives "No question asked yet.".
Totals this round: chat 6 attempts (6 x 200), embedding 3 attempts (3 x 200).
Files: q*_report.json (answers, tool calls, attempts), q*_trace.json, q*_console.txt (raw terminal frames).

## Retest after R45 (commit 66f7815) — q3b, 16:47, chat cap 10 (16 for the day minus 6 spent)

| # | Mode | Question | Chat attempts | Embed attempts | Tools | Result |
|---|---|---|---|---|---|---|
| q3b | interactive | What is the toughness of a space marine? | 2 (200, 200) | 0 | run_sql: factionId 'SM' + keyword Infantry, Legends excluded by source name, grouped by T | Mostly passed: queried the DB, T4 typical (90 datasheets), exceptions T3/T5/T6/T7 from the rows, cited [DB: datasheets_models]. Gaps: the reading of "space marine" is only implied ("Space Marine Infantry"), the Legends exclusion is not said; units with two profiles (Wardens of Ultramar T3+T4, Talonstrike and Decimus Kill Teams T4+T6) are listed under one exception value only. |

Day totals after q3b: chat 8 attempts (8 x 200); embedding 16 attempts (10 x 200, 6 x 429 from the first build).

## Retest after 655d68d — q3c, 20:55, chat cap 8

| # | Mode | Question | Chat attempts | Embed attempts | Tools | Result |
|---|---|---|---|---|---|---|
| q3c | interactive | What is the toughness of a space marine? | 2 (200, 200) | 0 | run_sql: SM + Infantry (keyword joined, not the example's subquery), Legends excluded, per T: profiles as "ID unit: profile"; not truncated | Scope said ("Space Marine Infantry units, excluding Warhammer Legends"); T4 most common (90 datasheets); representative exceptions T5/T6/T7 avoid the mixed units; T3 given to the named profiles "from Wardens of Ultramar", not to the whole unit. Notes: that unit's T4 profiles not mentioned; one citation holds a result row ("[DB: 000004188 Wardens of Ultramar: …]") instead of "[DB: table]". |

Day totals after q3c: chat 10 attempts (10 x 200); embedding 16 attempts (10 x 200, 6 x 429 from the first build). Acceptance budget left: 6 of 16.

## Retest — q1b grenades, 21:03, chat cap 6

| # | Mode | Question | Chat attempts | Embed attempts | Tools | Result |
|---|---|---|---|---|---|---|
| q1b | interactive | What is the rule for grenades? | 3 (200 x3) | 1 (200) | search_rules "grenades" -> pp. 42, 26, 46, 25; run_sql: stratagems WHERE name = 'GRENADE' AND FactionId = '' (1 row) | Both sources queried; TARGET and EFFECT differences quoted from both (DB: excludes units that Advanced, Fell Back or have shot; selects one GRENADES model). Missing: the DB record's source not recorded (edition rule, plan §7); no sentence saying the two texts differ and which is the 10th-edition rulebook. Extra: BLAST, TORRENT, IGNORES COVER added as abilities "which may include grenade-like weapons", a link the results do not make. |

Day totals after q1b: chat 13 attempts (13 x 200); embedding 17 (11 x 200, 6 x 429 from the first build). Acceptance budget left: 3 of 16.
