"""Online acceptance of steps 5-6: drives the CLI's own code, with the chat attempts capped.

Usage (from the repository root):
    uv run python drive.py interactive <out_dir> <chat_limit> <tag> <question>
    uv run python drive.py question <out_dir> <chat_limit> <tag> <question> > answer.txt 2> status.txt

Only `create_chat_model` and `GeminiEmbedder` are wrapped, to give them counting transports; every
chat attempt is counted before it is sent and refused past the limit (retries included).
"""

import argparse
import json
import os
import sys
from pathlib import Path

REPO = Path(r"D:\0-Labs\Broadening 1\chatbot")
sys.path.insert(0, str(REPO))

import httpx  # noqa: E402
from rich.console import Console  # noqa: E402

from src.rag.llm import gemini  # noqa: E402
from src.scripts import chat  # noqa: E402
from tests.gemini_check import RecordingTransport, RequestBudget  # noqa: E402

mode, out_dir, limit, tag, question = sys.argv[1:6]
out = Path(out_dir)
out.mkdir(parents=True, exist_ok=True)


class EmbedCounter(httpx.HTTPTransport):
    def __init__(self):
        super().__init__()
        self.statuses: list[int] = []

    def handle_request(self, request):
        response = super().handle_request(request)
        self.statuses.append(response.status_code)
        return response


budget = RequestBudget(int(limit), min_interval=12.0)
chat_transport = RecordingTransport(budget)
embed_transport = EmbedCounter()
chat.create_chat_model = lambda s: gemini.create_chat_model(s, {"transport": chat_transport})
chat.GeminiEmbedder = lambda s: gemini.GeminiEmbedder(s, {"transport": embed_transport})

answers = []
error = None
try:
    if mode == "interactive":
        os.environ["TERM"] = "xterm-256color"
        agent = chat.build_agent(argparse.ArgumentParser(prog="chat"))
        real_last_answer = agent.last_answer

        def capture():
            answer = real_last_answer()
            answers.append(answer)
            return answer

        agent.last_answer = capture
        lines = iter([question, "/sources", "/reset", "/sources", "/quit"])
        with (out / f"{tag}_console.txt").open("w", encoding="utf-8") as file:
            console = Console(
                file=file, width=110, force_terminal=True, color_system=None, legacy_windows=False
            )
            chat.chat_loop(agent, console, lambda: next(lines))
    else:
        sys.argv = ["chat", "--question", question]
        chat.main()
except SystemExit as stop:
    error = None if stop.code in (0, None) else f"SystemExit({stop.code})"
    raise
except BaseException as exc:  # noqa: BLE001
    error = f"{type(exc).__name__}: {exc}"
    raise
finally:
    report = {
        "question": question,
        "mode": mode,
        "chat_attempts": [e.status for e in chat_transport.exchanges],
        "chat_spent": budget.spent,
        "embed_attempts": embed_transport.statuses,
        "error": error,
        "answers": [
            {
                "text": a.text,
                "finish_reason": a.finish_reason,
                "tool_calls": [
                    {"name": c.name, "arguments": c.arguments, "pages": c.pages, "error": c.error, "output": c.output}
                    for c in a.tool_calls
                ],
                "model_calls": [[m.node, m.input_count, m.tool_choice] for m in a.trace.model_calls],
            }
            for a in answers
        ],
    }
    (out / f"{tag}_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    for a in answers:
        (out / f"{tag}_trace.json").write_text(
            json.dumps(a.trace.to_dict(), ensure_ascii=False, default=str), encoding="utf-8"
        )
