# R94 Stage C end-to-end online acceptance review (`gemini-3.8-flash`)

Date: 2026-10-23

## Scope and request accounting

After migrating `chat_model` to `gemini-3.8-flash` (`chat_temperature = None`, `tool_choice = {"mode": "VALIDATED"}`),
the user authorized executing the six Stage C end-to-end acceptance cases (`toughness` + `Wardens` follow-up,
independent `wardens`, `stratagem`, `scoring`, `grenades`, and `unit_rules` + `Advance` follow-up).

Three initial diagnostic runs (`20261023-105727_toughness_interactive`, `20261023-105927_wardens_interactive`, and
`20261023-110032_stratagem_interactive`, using `prompts.py` SHA-256
`0812b0835120aa3a24facba4a8f40172204e69ce5db6e05bf622adb5810545d1`) are preserved in full:

1. `20261023-105727_toughness_interactive` (5 chat / 0 embedding, all HTTP 200): completed both turns and verified the
   `_sql_notes` `publication` alias fix, but included an inline parenthetical cross-publication T4 sum in prose
   (`94 model profiles across 85 datasheets in edition 11` instead of `87` across `83` in edition 11).
2. `20261023-105927_wardens_interactive` (3 chat / 0 embedding, all HTTP 200): issued three sequential single-table SQL
   queries (`datasheets`, `datasheets_models`, `source`) instead of joining them as in Schema Example 1, exhausting its
   local `--budget 3` before generating the final answer.
3. `20261023-110032_stratagem_interactive` (4 chat / 3 embedding, all HTTP 200): retrieved all required Stratagem,
   Command phase, Battle-shock, and card sections on its first `search_rules` call, then issued three additional
   searches for a standalone definition of the card labels `WHEN`, `TARGET`, `EFFECT`, and `RESTRICTIONS`, exhausting
   `--budget 4`.

Three targeted clarifications were made directly in `src/rag/chatbot/prompts.py` (new SHA-256
`3d0002dcdbdaae12c78d0aaf06dda3fe3a263278b0aa0a970fe16535d1811740`):
- In `TOOL_RULES`: for a specific named unit, join `datasheets`, `datasheets_models`, and `source` in a single query
  (Schema Example 1) instead of separate queries per table.
- In `ANSWER_RULES`: illustrate how the card labels `WHEN`, `TARGET`, `EFFECT`, and `RESTRICTIONS` work from the
  retrieved Stratagem cards without searching again for a separate definition of those card labels once `STRATAGEMS`,
  `1. COMMAND`, and the cards are retrieved.
- In `ANSWER_RULES` (`Categories:`): report per-publication/edition counts as returned without summing them across
  publications or editions in prose.

All six Stage C end-to-end cases were then executed against the unified codebase (`prompts.py` SHA-256
`3d0002dcdbdaae12c78d0aaf06dda3fe3a263278b0aa0a970fe16535d1811740`):

- Final Stage C chat attempts: **19 / 27** (all HTTP 200, 0 retries, 0 malformed calls).
- Final Stage C embedding attempts: **6 / 16** (all HTTP 200, 0 retries).
- Combined round total (including the 3 preserved diagnostic runs): **31 chat / 9 embedding** attempts, all HTTP 200.
- Quota/authentication failures: none.
- Index rebuilds and RAGAS runs: none.

## Human verdicts (Final Stage C runs)

| Case | Directory | Calls (chat / embed) | Verdict | Evidence |
|---|---|---|---|---|
| Toughness + Wardens follow-up | `20261023-111254_toughness_interactive` | 5 / 0 | **Pass** | Turn 1 executes 1 aggregate SQL query + 1 representative mixed-profile SQL query (3 chat calls). Prose lists all 17 publication/edition/Toughness groups matching `database_statistics` verbatim, without any cross-publication prose sum, and preserves all mixed profiles (`Wardens of Ultramar` T4/T3, `Decimus Kill Team` T6/T4, `Talonstrike Kill Team` T6/T4). Turn 2 (`Wardens of Ultramar`, 2 chat calls) returns all T4 (`Ancient Gadriel, Veteran Sergeant Metaurus`) and T3 (`Gaius Silva, Aemelia Minervas, Dainal Kornelius, Lucia Vestha`) profiles, publication *Space Marines*, edition 11, and matching `source_notes` (`This turn: Database publication for Wardens of Ultramar: Space Marines; edition 11.`). |
| Independent Wardens | `20261023-110606_wardens_interactive` | 3 / 0 | **Pass** | Completes within `--budget 3`. Prose and `source_notes` both report `Wardens of Ultramar` (*Space Marines*, edition 11) with line 1 T4 (`Ancient Gadriel, Veteran Sergeant Metaurus`) and line 2 T3 (`Gaius Silva, Aemelia Minervas, Dainal Kornelius, Lucia Vestha`). |
| Stratagem | `20261023-110717_stratagem_interactive` | 2 / 1 | **Pass** | Single `search_rules(query="STRATAGEMS")` attaches `2. BATTLE-SHOCK` and 8 core DB records. Prose states `"At the start of a player's Command phase, before doing anything else, both players gain 1CP [Core Rules p. 11]"` and `"having gained at least 1CP at the start of each player's Command phase"`, preserves CP payment and once-per-phase limit, preserves the controlling-player Battle-shock restriction and `Insane Bravery` exception (`[Core Rules p. 42]`), and attributes PDF vs `[DB: stratagems]` card examples separately. |
| Scoring | `20261023-110826_scoring_interactive` | 2 / 1 | **Pass** | Single `search_rules(query="victory points and objective control for scoring")` retrieves pp. 59, 58, 60, 3. Prose names the `Only War` mission (`[Core Rules p. 59–60]`), separates introductory remarks (`[Core Rules p. 3]`) from `Capture and Control` (from battle round 2, at the end of each player's Command phase, active player scores 1 VP per controlled objective marker, max 3 VP/turn), explains objective marker control (`3"` horizontal / `5"` vertical, OC sum, contested), and preserves all three ordered branches of `11 Determine Victor` at the shared timing `"At the end of the battle"` (destroyed army, otherwise most VP, tie is a draw). `source_notes` displays `ONLY WAR (Core Rules p. 59)` and `ONLY WAR (Core Rules p. 60)`. |
| GRENADE | `20261023-110926_grenades_interactive` | 3 / 2 | **Pass** | Separates **Core Rules (10th Edition, p. 42)** and **Database Record (`[DB: stratagems]`, publication/edition not recorded)**. Preserves 1 CP cost, Shooting phase timing, 6D6 4+ mortal wounds, and both material differences: target exclusions (`not been selected to shoot this phase` vs `excluding units that Advanced, Fell Back, or have shot this turn`) and 8" range/visibility origin (`from your Grenades unit` vs `from a selected GRENADES model in your unit`). |
| Intercessor + Advance follow-up | `20261023-111052_unit_rules_interactive` | 4 / 2 | **Pass** | Turn 1 calls `search_rules` and `run_sql` together, establishes the `Grenades` keyword on `Intercessor Squad` (*Space Marines*, edition 11), and compares both `GRENADE` versions in a structured table. Turn 2 searches `Advance Advances Advanced` (`[Core Rules p. 14]`) and evaluates each source separately: for the Core Rules PDF, distinguishes nonselection from ineligibility to shoot and states that an absent Advance exclusion proves neither permission nor prohibition; for `[DB: stratagems]`, applies the explicit `(excluding units that Advanced, Fell Back or have shot this turn)` exclusion. |

## Conclusions

All six Stage C end-to-end acceptance cases pass both their model-answer semantic criteria and their application
provenance/statistics criteria under `gemini-3.8-flash`. Cross-review issues **P1-03** and **P1-07** are now closed with
complete saved runtime traces, console outputs, and SHA-256 manifests in `request-ledger.json`.
