"""Diagnosis of two retrieval misses (plan R61, R62): the ways to score (p. 59) and the trial's q004 (p. 22).

Run from the repository root:

    uv run python data/checks/diagnosis/20261018-retrieval-misses/diagnose.py
    uv run python data/checks/diagnosis/20261018-retrieval-misses/diagnose.py --embed-q004 --budget 3 --send

Without `--embed-q004` nothing is sent: the BM25 rankings are computed again from the saved chunks, and the vector
ranks of the returned chunks are inferred from the fused scores saved in the traces. With `--embed-q004 --send`,
the question of q004, as the evaluation searched it, is embedded once more with the index's model, dimension and
task type, under its own attempt cap (retries included), and its vector, rankings and fusion are saved. That vector
is a reproduction under the current settings, not the vector of the original run, which was not saved.
Each run writes `offline-<time>.json` next to this script, a fixed snapshot never overwritten; with `--send`, also
`q004_direct_embedding-<time>.json`, written whether the request succeeds or not (the attempts, and the error and
`complete: false` on a failure, without rankings), and naming the snapshot, inputs, model, dimension, task type and
code it goes with.
"""

import argparse
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
from rank_bm25 import BM25Okapi

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT))

from src.rag.chatbot.agent import RunTrace, answer_from_trace, chunk_block  # noqa: E402
from src.rag.chunker.markdown_chunker import jsonl_to_chunks  # noqa: E402
from src.rag.config import EMBEDDING_DIM, RULES_CHUNKS, RULES_EMBEDDINGS, TOP_K, Settings  # noqa: E402
from src.rag.llm.budget import AttemptCounter, RequestBudget  # noqa: E402
from src.rag.llm.gemini import GeminiEmbedder  # noqa: E402
from src.rag.retriever.rules_retriever import RRF_K, tokens  # noqa: E402
from src.rag.storage.evaluation_runs import load_answers  # noqa: E402
from src.rag.storage.rules_index import load_embeddings  # noqa: E402

HERE = Path(__file__).resolve().parent
SCORING_TRACE = ROOT / "data/checks/acceptance/20261018-121418_scoring_interactive/trace.json"
TRIAL_ANSWERS = ROOT / "data/eval/runs/trial/answers"
EMBEDDING_MODEL = "gemini-embedding-001"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


chunks = jsonl_to_chunks(RULES_CHUNKS.read_text(encoding="utf-8"))
ids = [chunk.chunk_id for chunk in chunks]
vectors = load_embeddings(RULES_EMBEDDINGS, chunks, EMBEDDING_MODEL)  # refuses an index of other chunks
bm25 = BM25Okapi([tokens(chunk.text) for chunk in chunks])


def bm25_ranking(query: str) -> tuple[np.ndarray, list[int]]:
    """As `RulesRetriever.search`: the chunks sharing a word with the query, best first."""
    scores = bm25.get_scores(tokens(query))
    return scores, [int(i) for i in np.argsort(-scores, kind="stable") if scores[i] > 0]


def keyword_case(query: str, target: str) -> dict:
    scores, order = bm25_ranking(query)
    t = ids.index(target)
    return {
        "query": query,
        "tokens": tokens(query),
        "chunks_with_a_shared_word": len(order),
        "target": target,
        "target_section": chunks[t].section,
        "target_pages": chunks[t].pages,
        "target_bm25": float(scores[t]),
        "target_bm25_rank": order.index(t) + 1 if t in order else None,
        "query_words_in_target": [w for w in dict.fromkeys(tokens(query)) if w in set(tokens(chunks[t].text))],
        "bm25_top10": [
            {"rank": r, "chunk": ids[i], "bm25": float(scores[i]), "section": chunks[i].section}
            for r, i in enumerate(order[:10], 1)
        ],
    }


def fused_case(query: str, target: str, returned: list[tuple[str, float]]) -> dict:
    """The keyword case, plus the vector ranks the saved fused scores imply for the returned chunks,
    and the highest fused score the target could have had with the best vector rank."""
    case = keyword_case(query, target)
    _, order = bm25_ranking(query)
    implied = []
    for chunk_id, fused in returned:
        i = ids.index(chunk_id)
        bm25_rank = order.index(i) + 1 if i in order else None
        rest = fused - (1 / (RRF_K + bm25_rank) if bm25_rank else 0.0)
        implied.append(
            {"chunk": chunk_id, "fused": fused, "bm25_rank": bm25_rank, "implied_vector_rank": 1 / rest - RRF_K}
        )
    target_bm25 = 1 / (RRF_K + case["target_bm25_rank"]) if case["target_bm25_rank"] else 0.0
    case |= {
        "returned": implied,
        "fifth_fused": min(fused for _, fused in returned),
        "target_fused_with_vector_rank_1": 1 / (RRF_K + 1) + target_bm25,
    }
    return case


def offline() -> dict:
    scoring = answer_from_trace(RunTrace.from_dict(json.loads(SCORING_TRACE.read_text(encoding="utf-8"))))
    (q4,) = [a for a in load_answers(TRIAL_ANSWERS) if a.question.question_id == "q004"]
    agent_q4 = answer_from_trace(q4.trace)
    return {
        "inputs": {
            str(path.relative_to(ROOT)): sha256(path)
            for path in [RULES_CHUNKS, RULES_EMBEDDINGS, SCORING_TRACE, *sorted(TRIAL_ANSWERS.glob("*.json"))]
        },
        "code": subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True).stdout.strip(),
        "settings": {"top_k": TOP_K, "rrf_k": RRF_K, "chunks": len(chunks)},
        "the ways to score, agent query": fused_case(
            scoring.tool_calls[0].arguments["query"],
            "core_rules-0243",
            [(f.chunk.chunk_id, f.score) for f in scoring.tool_calls[0].result],
        ),
        "q004, agent query": fused_case(
            agent_q4.tool_calls[0].arguments["query"],
            "core_rules-0081",
            [(f.chunk.chunk_id, f.score) for f in agent_q4.tool_calls[0].result],
        ),
        "q004, the evaluation's own search with the question": keyword_case(q4.question.question, "core_rules-0081")
        | {"returned_then": [block.split("]")[0][1:] for block in q4.retriever_contexts]},
    }


def embed_q004(budget: int, meta: dict) -> dict:
    """Embed q004's question once more and fuse as `RulesRetriever.search` does. Returns the record
    to save: on any failure (a refused budget, an HTTP error, Ctrl+C), the attempts so far and the
    error, `complete: false`, no ranking."""
    (q4,) = [a for a in load_answers(TRIAL_ANSWERS) if a.question.question_id == "q004"]
    query = q4.question.question
    then = [block.split("]")[0][1:] for block in q4.retriever_contexts]
    counter = AttemptCounter(RequestBudget(budget, 0))
    record = meta | {
        "note": "a reproduction under the current settings; the original query vector was not saved",
        "query": query,
        "budget": budget,
        "top_k_then": then,
        "complete": False,
    }
    try:
        embedder = GeminiEmbedder(Settings(), {"transport": counter})
        assert embedder.model == EMBEDDING_MODEL
        query_vector = embedder.embed([query], "RETRIEVAL_QUERY")[0]
    except BaseException as error:
        record |= {"attempts": counter.attempts, "error": f"{type(error).__name__}: {error}"}
        return record
    cosines = vectors @ query_vector
    by_vector = [int(i) for i in np.argsort(-cosines, kind="stable")]
    bm25_scores, by_keyword = bm25_ranking(query)
    fused = np.zeros(len(chunks))
    for ranking in (by_vector, by_keyword):
        for rank, index in enumerate(ranking, start=1):
            fused[index] += 1 / (RRF_K + rank)
    best = [int(i) for i in np.argsort(-fused, kind="stable")]

    def row(i: int) -> dict:
        return {
            "chunk": ids[i],
            "section": chunks[i].section,
            "vector_rank": by_vector.index(i) + 1,
            "cosine": float(cosines[i]),
            "bm25_rank": by_keyword.index(i) + 1 if i in by_keyword else None,
            "bm25": float(bm25_scores[i]),
            "fused": float(fused[i]),
            "fused_rank": best.index(i) + 1,
        }

    new_top = [ids[i] for i in best[:TOP_K]]
    return record | {
        "complete": True,
        "attempts": counter.attempts,
        "error": None,
        "query_vector": [float(x) for x in query_vector],
        "top_k_now": new_top,
        "same_top_k_as_then": new_top == then,
        "target": row(ids.index("core_rules-0081")),
        "all_chunks_by_fused_rank": [row(i) for i in best],
        "then_blocks_match_the_chunks": [
            chunk_block(chunks[ids.index(c)]) == b for c, b in zip(then, q4.retriever_contexts, strict=True)
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--embed-q004", action="store_true", help="embed q004's question once more")
    parser.add_argument("--budget", type=int, default=3, help="the most embedding attempts, retries included")
    parser.add_argument("--send", action="store_true", help="send; without it, only say what would be sent")
    args = parser.parse_args()
    started = time.strftime("%Y%m%d-%H%M%S")
    result = offline()
    snapshot = HERE / f"offline-{started}.json"
    snapshot.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")
    print(f"offline diagnosis -> {snapshot}")
    if args.embed_q004 and not args.send:
        print(f"Would embed q004's question once, at most {args.budget} attempts. Nothing sent: add --send.")
    elif args.embed_q004:
        meta = {
            "offline_snapshot": snapshot.name,
            "inputs": result["inputs"],
            "code": result["code"],
            "model": EMBEDDING_MODEL,
            "dimension": EMBEDDING_DIM,
            "task_type": "RETRIEVAL_QUERY",
            "settings": result["settings"],
        }
        embedded = embed_q004(args.budget, meta)
        path = HERE / f"q004_direct_embedding-{started}.json"
        path.write_text(json.dumps(embedded, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")
        print(f"complete {embedded['complete']}, attempts {embedded['attempts']}, error {embedded['error']} -> {path}")


if __name__ == "__main__":
    main()
