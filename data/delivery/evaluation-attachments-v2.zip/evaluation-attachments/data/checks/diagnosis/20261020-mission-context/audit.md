# D1 离线审查：任务归属能否有依据地进入上下文

2026-10-20。只读了解析结果（`core_rules.md`、`core_rules.json`）、代码和原始 PDF（pp. 53、59–60，只读）；没有改动任何文件（`data/raw/` 未改），也没有调用 API。

## 1. 标题层级不能整体使用

`heading_paths` 按 `#` 的个数推断上级标题（这个层级是 Docling 按字号推断的）。完整的路径列表见 `heading_paths.txt`（238 个标题，已去掉根节点）。

**对的部分**：p.59–60 的 11 个步骤和 `CAPTURE AND CONTROL` 都在 `MISSIONS > ONLY WAR` 下面；`ONLY WAR` 和 `OBJECTIVE MARKERS` 是 `MISSIONS` 下面的同级标题。

**错的部分**（对照 PDF 或文档结构核实）：
- **根节点**：整份文档都挂在 `Introduction`（L2）下面。
- **p.53 `AIRCRAFT`**：被放在 `TERRAIN FEATURES > EXAMPLE BATTLEFIELDS` 下面。PDF 上 p.53 是独立的 AIRCRAFT 章节，页脚印的是 `CORE RULES | AIRCRAFT`。
- **p.60 的步骤 6–11**：被放在 `5 DECLARE BATTLE FORMATIONS` 下面。PDF 上它们和步骤 5 是同级的；步骤 4、5 的标题印成两行，推断出来的层级是 L7，其他步骤是 L9。
- **p.45–48 的各类地形**（`CRATERS AND RUBBLE`、`WOODS`、`RUINS` 等）：被放在 `BENEFIT OF COVER` 下面。
- **提示框和摘要框**：被挂到它前面的那个标题下面。例如 `GAINING COMMAND POINTS` 挂在 `2. BATTLE-SHOCK` 下，`Hints and Tips FAST DICE ROLLING` 挂在 `DEADLY DEMISE` 下，`LEADERSHIP TESTS` 挂在 `7 WARGEAR OPTIONS` 下，`MORTAL WOUNDS` 挂在 `4. SAVING THROW` 下。

**结论**：如果把完整路径展示给模型，好几处会给出错误的归属。连 L≤5 的上级标题也有出错的（AIRCRAFT）。所以不能按层级截取一段当作"已核实"。这也和 `section_names` 的说明一致："the ancestors inferred from the levels are least reliable"。

## 2. 印刷页脚：已核实的这些页上有栏目页脚

**已核实**：p.53 是 `CORE RULES | AIRCRAFT`，p.59–60 是 `CORE RULES | MISSION: ONLY WAR`；p.59 的 `ONLY WAR` 标题旁边还印着 `MISSION`。p.40（整页插图）和 p.55（章节首页）在 PDF 上没有印页脚。其余没有页脚的页（p.1–3、5、50、56），原因没有逐页核实。

**在解析结果里**（`core_rules.json`，没有重新解析）：页面装饰在版面上分成两行，可以只按位置区分：

| 行（距页顶，单位 pt） | 内容 | 页数 |
|---|---|---|
| 693–701 | 页码 | 第 5–60 页 |
| 744–752，最低的一行 | 栏目页脚 | 51 页，每页正好一条 |

- 页脚这一行的标签有三种：`page_footer`、`caption`（p.11、35）、`text`（p.31），都在 furniture 层。
- 奇数页和偶数页的页脚分别印在左右两侧，所以要取这一行上的所有区域，不能只取一个区域。只取一个区域的话，只能取到偶数页，我第一次尝试就是这样。
- 没有任何一页取到的是页码。
- 没有页脚的页：p.1–5、40、50、55、56。p.4 本来就在 `SKIP_PAGES` 里。

**"Only War 是一个任务"有两个独立的依据**：p.57 正文写着 "The Core Rules include a single mission - Only War"；p.59–60 的页脚是 `MISSION: ONLY WAR`。都不需要靠标题名字去猜。

**Markdown 和 JSON 来自同一次解析**：由已提交的 JSON 重新导出（`export_pages` 加 `pages_to_markdown`），得到的文本和已提交的 `core_rules.md` 逐字相同。这个检查用时约 13 秒，不需要 Docling 模型。

## 3. 实现方案（待审）

1. **解析器**：在 `docling_parser.py` 里新增 `page_footers(document) -> dict[int, str]`。
   - 复用 `furniture_zones`，取其中最低的那一行上的所有区域。
   - 每一页取这一行里唯一的那条 furniture 文本；如果一条都没有，或者多于一条，这一页就不记录。
   - 判断只看位置，不看标签，也不匹配任何文字。
   - 只读取，不改动文档。
2. **Chunk**：新增字段 `page_footers: list[str]`，和 `pages` 一一对应，某页没有页脚就记为 `""`。默认值是空列表，表示"没有记录"。
   - 旧的 `rules_chunks.jsonl` 行，以及旧 trace 里工具结果保存的 chunk，读回来都是空列表，不会被自动补上页脚。
   - `chunk_markdown` 新增一个可选参数 `page_footers: dict[int, str] | None`；不传就得到空列表。
3. **`chunk.py`**：新增 `--json`。
   - 只有 Markdown 用的是默认的规则书时，才默认使用 `RULES_JSON`；自定义的 Markdown 不传 `--json` 就没有页脚，不会配上默认规则书的页脚。
   - 使用 JSON 之前，先检查"由 JSON 重新导出的 Markdown 和输入的 Markdown 完全一致"，不一致就报错停止。
   - JSON 文件也列入 `refuse_unsafe_outputs` 的输入。
4. **显示**：在 `agent.py` 的 `chunk_block` 里，页码后面按页附上原文页脚，例如：
   - 单页：`[core_rules-0243] Core Rules p. 59 (page footer: CORE RULES | MISSION: ONLY WAR)`
   - 跨页：`… p. 34–35 (page footers: p. 34 CORE RULES | …; p. 35 CORE RULES | …)`

   只列出有页脚的页。没有任何页脚的 chunk，显示的格式和现在完全一样。提示不改。
5. **测试**：
   - 用小型文档做 `page_footers` 的单元测试：两侧位置；页码那一行不会被取到；标签不同；一页多条时不记录；
   - 慢速测试用真实的 JSON：51 页；p.59–60；p.11、31、35；p.40、55 为空；
   - chunk 的页脚和页一一对应，包括跨页的情况；
   - JSON 往返；旧的行不带这个字段也能读；
   - `chunk_block` 的三种格式；
   - `chunk.py` 遇到 JSON 和 Markdown 不一致时拒绝执行。
6. **验证不变的范围**：重新生成 chunk 之后，和现有文件逐项对比：数量、顺序、ID、正文、pages、section、content_type、pictures 都不变；索引指纹不变，现有的向量可以加载；用 R68 保存的 36 个查询向量，确认 BM25、向量和融合三种排名都不变。
7. **文档**：
   - `lab1_1003.md` 里整段收录的 §10.2、§17.1、§17.2、§19.1、§19.2，以及相关说明；
   - README（chunk 命令和输出字段）；
   - plan 的 R71；
   - 缺陷表。

   解析出的规则书文件不变，不需要重新解析。

## 4. 在线回放（另行申请授权）

沿用 R70 的做法：查询和检索结果都固定。工具结果用 trace 里保存的 chunk 重新渲染，换成新的 chunk 显示格式。为了证明两组只差页脚，先离线核对：用新格式渲染旧 chunk（没有页脚）时，结果和保存下来的工具消息逐字相同。

两份得分样本的验收目标分开：
- **R69**（上下文里有计分规则）：检查页脚能不能帮助回答准确说明 Only War 的适用范围。
- **R61**（上下文里没有计分规则）：页脚最多能帮助说明 p.60 的判胜规则属于 Only War，不能据此补写没有收到的计分内容。

另外加 2 个回归样本，检查有没有产生错误的泛化。每组每份样本回答 2 次。

这次修复的目标只有一个：让已有的任务归属信息进入上下文，不承诺顺带解决漏检、判胜条件遗漏或其他回答错误。
