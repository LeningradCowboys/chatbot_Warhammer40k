"""Check that a chunk file with page footers changes nothing but the footers (plan R71).

    uv run python data/checks/diagnosis/20261020-mission-context/verify_unchanged.py NEW_CHUNKS

Compared with the current `data/index/rules_chunks.jsonl`: the number, order, IDs and every other field of the
chunks; the index fingerprint, and that the saved embeddings load for the new chunks; and, on the 36 query vectors
of R68's experiment, the vector ranking, the BM25 scores and `RulesRetriever.search`'s fused results (chunks and
scores), all chunks ranked. Nothing is sent. Writes `verify-<time>.json` beside this script.
"""

import hashlib
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT))

from src.rag.chunker.markdown_chunker import jsonl_to_chunks  # noqa: E402
from src.rag.config import RULES_CHUNKS, RULES_EMBEDDINGS  # noqa: E402
from src.rag.retriever.rules_retriever import RulesRetriever, tokens  # noqa: E402
from src.rag.storage.rules_index import index_fingerprint, load_embeddings  # noqa: E402

MODEL = "gemini-embedding-001"
VECTORS = ROOT / "data/checks/experiments/20261018-rrf-weights/vectors-20261019-175154.json"


class SavedVectors:
    """An `Embedder` that returns R68's saved query vectors, and sends nothing."""

    def __init__(self, record: dict):
        self._of = dict(zip(record["queries"], np.array(record["vectors"]), strict=True))

    def embed(self, texts: list[str], task_type: str) -> np.ndarray:
        return np.array([self._of[text] for text in texts])


def main() -> None:
    new_path = Path(sys.argv[1])
    old = jsonl_to_chunks(RULES_CHUNKS.read_text(encoding="utf-8"))
    new = jsonl_to_chunks(new_path.read_text(encoding="utf-8"))
    result = {"old": str(RULES_CHUNKS.relative_to(ROOT)), "old_sha256": hashlib.sha256(RULES_CHUNKS.read_bytes()).hexdigest(),
              "new": str(new_path), "new_sha256": hashlib.sha256(new_path.read_bytes()).hexdigest()}
    assert len(old) == len(new), (len(old), len(new))
    fields_other_than_footers = [
        {k: v for k, v in asdict(c).items() if k != "page_footers"} for c in old
    ] == [{k: v for k, v in asdict(c).items() if k != "page_footers"} for c in new]
    assert fields_other_than_footers, "a field other than the footers differs"
    assert all(c.page_footers == [] for c in old), "the current file already has footers"
    assert all(len(c.page_footers) == len(c.pages) for c in new)
    result["chunks"] = len(new)
    result["fields_other_than_footers_equal"] = True
    result["chunks_with_a_footer"] = sum(any(c.page_footers) for c in new)
    assert index_fingerprint(old, MODEL) == index_fingerprint(new, MODEL)
    result["index_fingerprint_equal"] = True
    vectors_old = load_embeddings(RULES_EMBEDDINGS, old, MODEL)
    vectors_new = load_embeddings(RULES_EMBEDDINGS, new, MODEL)  # raises if the fingerprint differs
    assert np.array_equal(vectors_old, vectors_new)
    result["embeddings_load_for_new_chunks"] = True
    record = json.loads(VECTORS.read_text(encoding="utf-8"))
    saved = SavedVectors(record)
    retrievers = [RulesRetriever(chunks, vectors_new, saved) for chunks in (old, new)]
    for query in record["queries"]:
        vector = saved.embed([query], "RETRIEVAL_QUERY")[0]
        by_vector = [np.argsort(-(r._vectors @ vector), kind="stable").tolist() for r in retrievers]
        assert by_vector[0] == by_vector[1], query
        bm25 = [r._bm25.get_scores(tokens(query)).tolist() for r in retrievers]
        assert bm25[0] == bm25[1], query
        fused = [[(f.chunk.chunk_id, f.score) for f in r.search(query, len(old))] for r in retrievers]
        assert fused[0] == fused[1], query
    result["queries_checked"] = len(record["queries"])
    result["vector_bm25_fused_rankings_equal"] = True
    out = HERE / f"verify-{time.strftime('%Y%m%d-%H%M%S')}.json"
    out.write_text(json.dumps(result, indent=1) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(result, indent=1))


if __name__ == "__main__":
    main()
